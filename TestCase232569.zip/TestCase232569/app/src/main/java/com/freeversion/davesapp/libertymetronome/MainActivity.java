package com.freeversion.davesapp.libertymetronome;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.util.TypedValue;
import android.widget.CompoundButton;
import android.widget.ToggleButton;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.appindexing.Thing;
import com.google.android.gms.common.api.GoogleApiClient;

import java.math.BigDecimal;
import java.util.Arrays;

//import static com.freeversion.davesapp.libertymetronome.R.id.toggleButton;

public class MainActivity extends Activity {

    // for NDK
    static AssetManager assetManager;
    static boolean isPlayingAsset = false;
    boolean created;
    public int mainBeat_buf_counter = 1;
    public int subBeat_buf_counter = 1;

    public static final String MY_PREFS_NAME = "MetronomeProperties";
    boolean paused = false;


    int TEMPO_MIN = 0;
    int TEMPO_MAX = 0;
    int TEMPO_RANGE = 0;

    public static int MAX_ANGLE = 0;
    public static int MIN_ANGLE = 0;
    public static int angleIncrement = 2;
    public static int homeAngleIncrement = 1;
    public static int direction = 1;
    float angle = 0;

    float weight_width = 0;
    float weight_height = 0;

    float pivotX = 149;
    float pivotY = 350;

    // tempo - this variable initialization is for development only
    public int bpmInt = 24;

    private Thread animator = null;
    private Thread soundThread = null;
    boolean hasStarted = false;
    boolean isHome = true;
    long soundInterval;
    long animationInterval;

    int noteForMainBeat = 42;
    int noteForSubBeat = 43;


    public static String skin = "classic";
    Drawable drawResID = null;
    String tempoTextColor = "";

    // For Programmable Metronome
    public static boolean programLoaded = false;
    boolean programRunning = false;
    static boolean repeatProgram = false;
    String targetFile = null;
    static String activeProgramName = null;
    static int MAX_SECTIONS = 16;
    static int numberOfSections = 1;
    static int[] startTempo = new int[MAX_SECTIONS + 1]; //"100";
    static int[] endTempo = new int[MAX_SECTIONS + 1]; //"100";
    static int[] incrementTempo = new int[MAX_SECTIONS + 1]; //"10";
    static int[] beatCountValue = new int[MAX_SECTIONS + 1]; //"8";
    static int[] subBeatValue = new int[MAX_SECTIONS + 1]; //"0";
    static int[] majorBeatSound = new int[MAX_SECTIONS + 1]; //"0";
    static int[] subBeatSound = new int[MAX_SECTIONS + 1]; //"0";

    String[] soundStrings = {"high_wood_block.wav", "low_wood_block.wav"};

    // Program runtime variables / counters
    int sectionCounter = 0;
    int start = 0;
    int end = 0;
    int programCounter = 0;
    int beatCounter = 0;
    int tempoIncrement = 0;
    int subBeatSoundIndex = 0;
    int majorBeatSoundIndex = 0;
    boolean firstMajorBeatPlayed = false;

    int currentapiVersion;  // get API Level
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;


    @Override
    @TargetApi(17)
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // temporarily mute volume
        AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        int amVolume = 5;
        amVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        if (amVolume == 0) {
            amVolume = audioManager.getStreamMaxVolume(audioManager.STREAM_MUSIC);
            new AlertDialog.Builder(this)
                    .setTitle("Load Program")
                    .setMessage("Your media player volume was muted.\nVolume has been restored to maximum.")
                    .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            //finish();
                        }
                    })
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .show();
        }
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0);


        currentapiVersion = Build.VERSION.SDK_INT;

        // Sounds are stored in the project "assets" folder
        assetManager = getAssets();

        // initialize native audio system
        createMainBeatEngine();
        createSubBeatEngine();

        int sampleRate = 0;
        int bufSize = 0;
        /*
         * retrieve fast audio path sample rate and buf size; if we have it, we pass to native
         * side to create a player with fast audio enabled [ fast audio == low latency audio ];
         * IF we do not have a fast audio path, we pass 0 for sampleRate, which will force native
         * side to pick up the 8Khz sample rate.
         */
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            AudioManager myAudioMgr = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            String nativeParam = myAudioMgr.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE);
            sampleRate = Integer.parseInt(nativeParam);
            nativeParam = myAudioMgr.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER);
            bufSize = Integer.parseInt(nativeParam);
        }


        // Create Audio Buffers
        createMainBeatAudioBuffer1(sampleRate, bufSize);
        createMainBeatAudioBuffer2(sampleRate, bufSize);
        createMainBeatAudioBuffer3(sampleRate, bufSize);

        createSubBeatAudioBuffer1(sampleRate, bufSize);
        createSubBeatAudioBuffer2(sampleRate, bufSize);
        createSubBeatAudioBuffer3(sampleRate, bufSize);
        createSubBeatAudioBuffer4(sampleRate, bufSize);
        createSubBeatAudioBuffer5(sampleRate, bufSize);
        createSubBeatAudioBuffer6(sampleRate, bufSize);
        createSubBeatAudioBuffer7(sampleRate, bufSize);
        createSubBeatAudioBuffer8(sampleRate, bufSize);

        bpmInt = 60;
        noteForMainBeat = 0;
        noteForSubBeat = 1;

        // Create all the sound players
        final String soundForMainBeat = Arrays.asList(soundStrings).get(noteForMainBeat);
        String soundForSubBeat = Arrays.asList(soundStrings).get(noteForSubBeat);

        //main beat players
        created = createSoundPlayerMainBeat1(assetManager, soundForMainBeat);
        created = createSoundPlayerMainBeat2(assetManager, soundForMainBeat);
        created = createSoundPlayerMainBeat3(assetManager, soundForMainBeat);
        isPlayingAsset = true;
        //sub beat players
        created = createSoundPlayerSubBeat1(assetManager, soundForSubBeat);
        created = createSoundPlayerSubBeat2(assetManager, soundForSubBeat);
        created = createSoundPlayerSubBeat3(assetManager, soundForSubBeat);
        created = createSoundPlayerSubBeat4(assetManager, soundForSubBeat);
        created = createSoundPlayerSubBeat5(assetManager, soundForSubBeat);
        created = createSoundPlayerSubBeat6(assetManager, soundForSubBeat);
        created = createSoundPlayerSubBeat7(assetManager, soundForSubBeat);
        created = createSoundPlayerSubBeat8(assetManager, soundForSubBeat);

        // rewind everybody
        int beQuiet = -5000;
        setVolumeMainBeat(beQuiet);
        setVolumeSubBeat(beQuiet);

        setPlayStateMainBeat1(true);
        setPlayStateMainBeat1(false);

        setPlayStateMainBeat2(true);
        setPlayStateMainBeat2(false);

        setPlayStateMainBeat3(true);
        setPlayStateMainBeat3(false);

        setPlayStateSubBeat1(true);
        setPlayStateSubBeat1(false);

        setPlayStateSubBeat2(true);
        setPlayStateSubBeat2(false);

        setPlayStateSubBeat3(true);
        setPlayStateSubBeat3(false);

        setPlayStateSubBeat4(true);
        setPlayStateSubBeat4(false);

        setPlayStateSubBeat5(true);
        setPlayStateSubBeat5(false);

        setPlayStateSubBeat6(true);
        setPlayStateSubBeat6(false);

        setPlayStateSubBeat7(true);
        setPlayStateSubBeat7(false);

        setPlayStateSubBeat8(true);
        setPlayStateSubBeat8(false);


        // restore volume level
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, amVolume, 0);

        int volumeUpper = 5;
        int volumeLower = 5;
        // MAIN BEAT VOLUME
        double volUd = Math.pow(volumeUpper, 1.0 / 5.0);
        float volUf = (float) volUd;
        int millibel = (5000- Math.round(volUf*5000)) * -1;
        if (millibel>0)
            millibel = 0;
        setVolumeMainBeat(millibel);
        // SUB BEAT VOLUME
        double volLd = Math.pow(volumeLower, 1.0 / 5.0);
        float volLf = (float) volLd;
        int millibelli = (5000- Math.round(volLf*5000)) * -1;
        if (millibelli>0)
            millibelli = 0;
        setVolumeSubBeat(millibelli);

        // Start & Stop Toggle
        ToggleButton toggle = (ToggleButton) findViewById(R.id.toggleButton);
        toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    hasStarted = true;
                    metronomeSound godoit = new metronomeSound();
                    long sDelay = Math.round(60000/bpmInt);
                    godoit.startSound(sDelay);
                } else {
                    // The toggle is disabled
                    hasStarted = false;
                }
            }
        });

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }


    class metronomeSound implements Runnable {

        @Override
        public void run(){
            // wait till we get to -24 degrees
            try { Thread.sleep(soundInterval/2); } catch (InterruptedException e) { ; }
            while (hasStarted){
                switch (1) {
                    case 0:
                        playMainBeat();
                        try {
                            Thread.sleep(soundInterval);
                        } catch (InterruptedException e) {
                            ;
                        }
                        break;
                    case 1:
                        playMainBeat();
                        try {
                            Thread.sleep(soundInterval/2);
                        } catch (InterruptedException e) {
                            ;
                        }
                        playSubBeat();
                        try {
                            Thread.sleep(soundInterval/2);
                        } catch (InterruptedException e) {
                            ;
                        }
                        break;
                    case 2:
                        playMainBeat();
                        try {
                            Thread.sleep(soundInterval/3);
                        } catch (InterruptedException e) {
                            ;
                        }
                        playSubBeat();
                        try {
                            Thread.sleep(soundInterval/3);
                        } catch (InterruptedException e) {
                            ;
                        } playSubBeat();
                        try {
                            Thread.sleep(soundInterval/3);
                        } catch (InterruptedException e) {
                            ;
                        }
                        break;
                }
            }
        }

        public void startSound(long interval) {
            soundInterval = interval;
            soundThread = new Thread(this);
            soundThread.setPriority(Thread.MAX_PRIORITY);
            soundThread.start();
        }


        public void playMainBeat() {
            switch (mainBeat_buf_counter) {
                case 1:
                    setPlayStateMainBeat1(true);
                    setPlayStateMainBeat2(false);
                    mainBeat_buf_counter = 2;
                    break;
                case 2:
                    setPlayStateMainBeat2(true);
                    setPlayStateMainBeat3(false);
                    mainBeat_buf_counter = 3;
                    break;
                case 3:
                    setPlayStateMainBeat3(true);
                    setPlayStateMainBeat1(false);
                    mainBeat_buf_counter = 1;
                    break;
            }
        }

        public void playSubBeat() {
            switch (subBeat_buf_counter) {
                case 1:
                    setPlayStateSubBeat1(true);
                    setPlayStateSubBeat2(false);
                    subBeat_buf_counter = 2;
                    break;
                case 2:
                    setPlayStateSubBeat2(true);
                    setPlayStateSubBeat3(false);
                    subBeat_buf_counter = 3;
                    break;
                case 3:
                    setPlayStateSubBeat3(true);
                    setPlayStateSubBeat4(false);
                    subBeat_buf_counter = 4;
                    break;
                case 4:
                    setPlayStateSubBeat4(true);
                    setPlayStateSubBeat5(false);
                    subBeat_buf_counter = 5;
                    break;
                case 5:
                    setPlayStateSubBeat5(true);
                    setPlayStateSubBeat6(false);
                    subBeat_buf_counter = 6;
                    break;
                case 6:
                    setPlayStateSubBeat6(true);
                    setPlayStateSubBeat7(false);
                    subBeat_buf_counter = 7;
                    break;
                case 7:
                    setPlayStateSubBeat7(true);
                    setPlayStateSubBeat8(false);
                    subBeat_buf_counter = 8;
                    break;
                case 8:
                    setPlayStateSubBeat8(true);
                    setPlayStateSubBeat1(false);
                    subBeat_buf_counter = 1;
                    break;
            }
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        hasStarted = false;

        shutDownAudioEngine();
        paused = true;
    }

    public void shutDownAudioEngine() {
        // shut down audio engine
        setPlayStateMainBeat1(false);
        setPlayStateMainBeat2(false);
        setPlayStateMainBeat3(false);
        shutdownMainBeat();

        setPlayStateSubBeat1(false);
        setPlayStateSubBeat2(false);
        setPlayStateSubBeat3(false);
        setPlayStateSubBeat4(false);
        setPlayStateSubBeat5(false);
        setPlayStateSubBeat6(false);
        setPlayStateSubBeat7(false);
        setPlayStateSubBeat8(false);
        shutdownSubBeat();

    }

    @Override
    public void onResume() {
        super.onResume();
        if (paused) {
            finish();
            paused = false;
            startActivity(getIntent());
        }
    }


    /**
     * Native methods, implemented in jni folder
     */
    public static native void shutdownMainBeat();

    public static native void createMainBeatEngine();

    public static native void setVolumeMainBeat(int millibel);

    public static native void createMainBeatAudioBuffer1(int sampleRate, int samplesPerBuf);

    public static native void createMainBeatAudioBuffer2(int sampleRate, int samplesPerBuf);

    public static native void createMainBeatAudioBuffer3(int sampleRate, int samplesPerBuf);

    public static native boolean createSoundPlayerMainBeat1(AssetManager assetManager1, String filename);

    public static native void setPlayStateMainBeat1(boolean isPlaying);  // true == PLAYING, false == PAUSED

    public static native boolean createSoundPlayerMainBeat2(AssetManager assetManager1, String filename);

    public static native void setPlayStateMainBeat2(boolean isPlaying);  // true == PLAYING, false == PAUSED

    public static native boolean createSoundPlayerMainBeat3(AssetManager assetManager1, String filename);

    public static native void setPlayStateMainBeat3(boolean isPlaying);  // true == PLAYING, false == PAUSED

    // Native methods for subBeat
    public static native void shutdownSubBeat();

    public static native void createSubBeatEngine();

    public static native void setVolumeSubBeat(int millibel);

    public static native void createSubBeatAudioBuffer1(int sampleRate, int samplesPerBuf);

    public static native void createSubBeatAudioBuffer2(int sampleRate, int samplesPerBuf);

    public static native void createSubBeatAudioBuffer3(int sampleRate, int samplesPerBuf);

    public static native void createSubBeatAudioBuffer4(int sampleRate, int samplesPerBuf);

    public static native void createSubBeatAudioBuffer5(int sampleRate, int samplesPerBuf);

    public static native void createSubBeatAudioBuffer6(int sampleRate, int samplesPerBuf);

    public static native void createSubBeatAudioBuffer7(int sampleRate, int samplesPerBuf);

    public static native void createSubBeatAudioBuffer8(int sampleRate, int samplesPerBuf);

    public static native boolean createSoundPlayerSubBeat1(AssetManager assetManager1, String filename);

    public static native void setPlayStateSubBeat1(boolean isPlaying);  // true == PLAYING, false == PAUSED

    public static native boolean createSoundPlayerSubBeat2(AssetManager assetManager1, String filename);

    public static native void setPlayStateSubBeat2(boolean isPlaying);  // true == PLAYING, false == PAUSED

    public static native boolean createSoundPlayerSubBeat3(AssetManager assetManager1, String filename);

    public static native void setPlayStateSubBeat3(boolean isPlaying);  // true == PLAYING, false == PAUSED

    public static native boolean createSoundPlayerSubBeat4(AssetManager assetManager1, String filename);

    public static native void setPlayStateSubBeat4(boolean isPlaying);  // true == PLAYING, false == PAUSED

    public static native boolean createSoundPlayerSubBeat5(AssetManager assetManager1, String filename);

    public static native void setPlayStateSubBeat5(boolean isPlaying);  // true == PLAYING, false == PAUSED

    public static native boolean createSoundPlayerSubBeat6(AssetManager assetManager1, String filename);

    public static native void setPlayStateSubBeat6(boolean isPlaying);  // true == PLAYING, false == PAUSED

    public static native boolean createSoundPlayerSubBeat7(AssetManager assetManager1, String filename);

    public static native void setPlayStateSubBeat7(boolean isPlaying);  // true == PLAYING, false == PAUSED

    public static native boolean createSoundPlayerSubBeat8(AssetManager assetManager1, String filename);

    public static native void setPlayStateSubBeat8(boolean isPlaying);  // true == PLAYING, false == PAUSED

    /** Load jni .so on initialization */
    static {
        System.loadLibrary("audioMainBeat");
    }

    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    public Action getIndexApiAction() {
        Thing object = new Thing.Builder()
                .setName("Main Page") // TODO: Define a title for the content shown.
                // TODO: Make sure this auto-generated URL is correct.
                .setUrl(Uri.parse("http://[ENTER-YOUR-URL-HERE]"))
                .build();
        return new Action.Builder(Action.TYPE_VIEW)
                .setObject(object)
                .setActionStatus(Action.STATUS_TYPE_COMPLETED)
                .build();
    }

    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        AppIndex.AppIndexApi.start(client, getIndexApiAction());
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        AppIndex.AppIndexApi.end(client, getIndexApiAction());
        client.disconnect();
    }
}
