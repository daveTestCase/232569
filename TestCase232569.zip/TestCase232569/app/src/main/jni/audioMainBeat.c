//
// Created by Dave on 6/23/2016.
//

/* This is a JNI example where we use native methods to play sounds
 * using OpenSL ES.
 */

#include <assert.h>
#include <jni.h>
#include <string.h>
#include <pthread.h>


// for __android_log_print(ANDROID_LOG_INFO, "YourApp", "formatted message");
// #include <android/log.h>

// for native audio
#include <SLES/OpenSLES.h>
#include <SLES/OpenSLES_Android.h>

// for native asset manager
#include <sys/types.h>
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>

// =================================================================
// GLOBALS for MainBeat
// =================================================================

// engine Object & Interfaces
static SLObjectItf engine_object_mainBeat = NULL;
static SLEngineItf engine_itf_mainBeat;

// output mix interfaces
static SLObjectItf output_MixObject_mainBeat = NULL;
SLVolumeItf output_MixObject_vol_mainBeat;


static SLVolumeItf player_vol_mainBeat;
static SLmilliHertz bqPlayerSampleRate_mainBeat = 0;
static jint   bqPlayerBufSize_mainBeat = 0;
static short *resampleBuf_mainBeat = NULL;
// a mutext to guard against re-entrance to record & playback
// as well as make recording and playing back to be mutually exclusive
// this is to avoid crash at situations like:
//    recording is in session [not finished]
//    user presses record button and another recording coming in
// The action: when recording/playing back is not finished, ignore the new request
static pthread_mutex_t  audioEngineLock_mainBeat = PTHREAD_MUTEX_INITIALIZER;


// buffer queue player interfaces
// FIRST BUFFER
static SLObjectItf buffer_obj_mainBeat_1 = NULL;        //(need 5 of these)
static SLPlayItf buffer_itf_mainBeat_1;                 //(need 5 of these)
static SLAndroidSimpleBufferQueueItf buf_q_mainBeat_1;  //(need 5 of these)
// SECOND BUFFER
static SLObjectItf buffer_obj_mainBeat_2 = NULL;        //(need 5 of these)
static SLPlayItf buffer_itf_mainBeat_2;                 //(need 5 of these)
static SLAndroidSimpleBufferQueueItf buf_q_mainBeat_2;  //(need 5 of these)
// THIRD BUFFER
static SLObjectItf buffer_obj_mainBeat_3 = NULL;        //(need 5 of these)
static SLPlayItf buffer_itf_mainBeat_3;                 //(need 5 of these)
static SLAndroidSimpleBufferQueueItf buf_q_mainBeat_3;  //(need 5 of these)
// FOURTH BUFFER
static SLObjectItf buffer_obj_mainBeat_4 = NULL;        //(need 5 of these)
static SLPlayItf buffer_itf_mainBeat_4;                 //(need 5 of these)
static SLAndroidSimpleBufferQueueItf buf_q_mainBeat_4;  //(need 5 of these)
// FIFTH BUFFER
static SLObjectItf buffer_obj_mainBeat_5 = NULL;        //(need 5 of these)
static SLPlayItf buffer_itf_mainBeat_5;                 //(need 5 of these)
static SLAndroidSimpleBufferQueueItf buf_q_mainBeat_5;  //(need 5 of these)


// file player interfaces
//FIRST
static SLObjectItf filePlayer_obj_mainBeat_1 = NULL;
static SLPlayItf filePlayer_itf_mainBeat_1;
static SLVolumeItf filePlayerVolume_mainBeat_1;
//SECOND
static SLObjectItf filePlayer_obj_mainBeat_2 = NULL;
static SLPlayItf filePlayer_itf_mainBeat_2;
static SLVolumeItf filePlayerVolume_mainBeat_2;
//THIRD
static SLObjectItf filePlayer_obj_mainBeat_3 = NULL;
static SLPlayItf filePlayer_itf_mainBeat_3;
static SLVolumeItf filePlayerVolume_mainBeat_3;
//FOURTH
static SLObjectItf filePlayer_obj_mainBeat_4 = NULL;
static SLPlayItf filePlayer_itf_mainBeat_4;
static SLVolumeItf filePlayerVolume_mainBeat_4;
//FIFTH
static SLObjectItf filePlayer_obj_mainBeat_5 = NULL;
static SLPlayItf filePlayer_itf_mainBeat_5;
static SLVolumeItf filePlayerVolume_mainBeat_5;



// =================================================================
// GLOBALS for SubBeat
// =================================================================

// engine Object & Interfaces
static SLObjectItf engine_object_subBeat = NULL;
static SLEngineItf engine_itf_subBeat;

// output mix interfaces
static SLObjectItf output_MixObject_subBeat = NULL;
SLVolumeItf output_MixObject_vol_subBeat;


static SLVolumeItf player_vol_subBeat;
static SLmilliHertz bqPlayerSampleRate_subBeat = 0;
static jint   bqPlayerBufSize_subBeat = 0;
static short *resampleBuf_subBeat = NULL;
// a mutext to guard against re-entrance to record & playback
// as well as make recording and playing back to be mutually exclusive
// this is to avoid crash at situations like:
//    recording is in session [not finished]
//    user presses record button and another recording coming in
// The action: when recording/playing back is not finished, ignore the new request
static pthread_mutex_t  audioEngineLock_subBeat = PTHREAD_MUTEX_INITIALIZER;


// buffer queue player interfaces
// FIRST BUFFER
static SLObjectItf buffer_obj_subBeat_1 = NULL;        //(need 5 of these)
static SLPlayItf buffer_itf_subBeat_1;                 //(need 5 of these)
static SLAndroidSimpleBufferQueueItf buf_q_subBeat_1;  //(need 5 of these)
// SECOND BUFFER
static SLObjectItf buffer_obj_subBeat_2 = NULL;        //(need 5 of these)
static SLPlayItf buffer_itf_subBeat_2;                 //(need 5 of these)
static SLAndroidSimpleBufferQueueItf buf_q_subBeat_2;  //(need 5 of these)
// THIRD BUFFER
static SLObjectItf buffer_obj_subBeat_3 = NULL;        //(need 5 of these)
static SLPlayItf buffer_itf_subBeat_3;                 //(need 5 of these)
static SLAndroidSimpleBufferQueueItf buf_q_subBeat_3;  //(need 5 of these)
// FOURTH BUFFER
static SLObjectItf buffer_obj_subBeat_4 = NULL;        //(need 5 of these)
static SLPlayItf buffer_itf_subBeat_4;                 //(need 5 of these)
static SLAndroidSimpleBufferQueueItf buf_q_subBeat_4;  //(need 5 of these)
// FIFTH BUFFER
static SLObjectItf buffer_obj_subBeat_5 = NULL;        //(need 5 of these)
static SLPlayItf buffer_itf_subBeat_5;                 //(need 5 of these)
static SLAndroidSimpleBufferQueueItf buf_q_subBeat_5;  //(need 5 of these)
// SIXTH BUFFER
static SLObjectItf buffer_obj_subBeat_6 = NULL;        //(need 5 of these)
static SLPlayItf buffer_itf_subBeat_6;                 //(need 5 of these)
static SLAndroidSimpleBufferQueueItf buf_q_subBeat_6;  //(need 5 of these)
// SEVENTH BUFFER
static SLObjectItf buffer_obj_subBeat_7 = NULL;        //(need 5 of these)
static SLPlayItf buffer_itf_subBeat_7;                 //(need 5 of these)
static SLAndroidSimpleBufferQueueItf buf_q_subBeat_7;  //(need 5 of these)
// EIGHTTH BUFFER
static SLObjectItf buffer_obj_subBeat_8 = NULL;        //(need 5 of these)
static SLPlayItf buffer_itf_subBeat_8;                 //(need 5 of these)
static SLAndroidSimpleBufferQueueItf buf_q_subBeat_8;  //(need 5 of these)
// NINETH BUFFER
static SLObjectItf buffer_obj_subBeat_9 = NULL;        //(need 5 of these)
static SLPlayItf buffer_itf_subBeat_9;                 //(need 5 of these)
static SLAndroidSimpleBufferQueueItf buf_q_subBeat_9;  //(need 5 of these)
// TENTH BUFFER
static SLObjectItf buffer_obj_subBeat_10 = NULL;        //(need 5 of these)
static SLPlayItf buffer_itf_subBeat_10;                 //(need 5 of these)
static SLAndroidSimpleBufferQueueItf buf_q_subBeat_10;  //(need 5 of these)




// file player interfaces
//FIRST
static SLObjectItf filePlayer_obj_subBeat_1 = NULL;
static SLPlayItf filePlayer_itf_subBeat_1;
static SLVolumeItf filePlayerVolume_subBeat_1;
//SECOND
static SLObjectItf filePlayer_obj_subBeat_2 = NULL;
static SLPlayItf filePlayer_itf_subBeat_2;
static SLVolumeItf filePlayerVolume_subBeat_2;
//THIRD
static SLObjectItf filePlayer_obj_subBeat_3 = NULL;
static SLPlayItf filePlayer_itf_subBeat_3;
static SLVolumeItf filePlayerVolume_subBeat_3;
//FOURTH
static SLObjectItf filePlayer_obj_subBeat_4 = NULL;
static SLPlayItf filePlayer_itf_subBeat_4;
static SLVolumeItf filePlayerVolume_subBeat_4;
//FIFTH
static SLObjectItf filePlayer_obj_subBeat_5 = NULL;
static SLPlayItf filePlayer_itf_subBeat_5;
static SLVolumeItf filePlayerVolume_subBeat_5;
//SIXTH
static SLObjectItf filePlayer_obj_subBeat_6 = NULL;
static SLPlayItf filePlayer_itf_subBeat_6;
static SLVolumeItf filePlayerVolume_subBeat_6;
//SEVENTH
static SLObjectItf filePlayer_obj_subBeat_7 = NULL;
static SLPlayItf filePlayer_itf_subBeat_7;
static SLVolumeItf filePlayerVolume_subBeat_7;
//EIGHTH
static SLObjectItf filePlayer_obj_subBeat_8 = NULL;
static SLPlayItf filePlayer_itf_subBeat_8;
static SLVolumeItf filePlayerVolume_subBeat_8;
//NINETH
static SLObjectItf filePlayer_obj_subBeat_9 = NULL;
static SLPlayItf filePlayer_itf_subBeat_9;
static SLVolumeItf filePlayerVolume_subBeat_9;
//TENTH
static SLObjectItf filePlayer_obj_subBeat_10 = NULL;
static SLPlayItf filePlayer_itf_subBeat_10;
static SLVolumeItf filePlayerVolume_subBeat_10;



//some flags to keep track of playback state
//jboolean is_playing, is_done_buffer;

// ================================================
// ================================================
//       MAIN BEAT CODE SECTION
// ================================================
// ================================================

//Define callback - used to stop a player when head reached end of buffer queue
//void SLAPIENTRY play_callback_mainBeat( SLPlayItf player,
//                               void *context, SLuint32 event )
//{
//    if( event & SL_PLAYEVENT_HEADATEND )
//        is_done_buffer = JNI_TRUE;
//}

void releaseresampleBuf_mainBeat(void) {
    if( 0 == bqPlayerSampleRate_mainBeat) {
        return;
    }
    free(resampleBuf_mainBeat);
    resampleBuf_mainBeat = NULL;
}

// create the engine and output mix objects
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_createMainBeatEngine(JNIEnv* env, jclass clazz)
{
    SLresult result;

    // create engine
    result = slCreateEngine(&engine_object_mainBeat, 0, NULL, 0, NULL, NULL);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the engine
    result = (*engine_object_mainBeat)->Realize(engine_object_mainBeat, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the engine interface, which is needed in order to create other objects
    result = (*engine_object_mainBeat)->GetInterface(engine_object_mainBeat, SL_IID_ENGINE, &engine_itf_mainBeat);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // create output mix with volume interface
    const SLInterfaceID ids[] = { SL_IID_VOLUME };
    const SLboolean req[] = { SL_BOOLEAN_FALSE };
    result = (*engine_itf_mainBeat)->CreateOutputMix(engine_itf_mainBeat, &output_MixObject_mainBeat, 1, ids, req );
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the output mix
    result = (*output_MixObject_mainBeat)->Realize(output_MixObject_mainBeat, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    if( (*output_MixObject_mainBeat)->GetInterface( output_MixObject_mainBeat,
                                         SL_IID_VOLUME, &output_MixObject_vol_mainBeat ) != SL_RESULT_SUCCESS )
        output_MixObject_vol_mainBeat = NULL;
}


// Create audio buffers, player, and set play state methods.   We will need 5 of these for main and 10 for sub beat
//===========================================================================================
//  FIRST SET
//===========================================================================================
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_createMainBeatAudioBuffer1(JNIEnv* env,
        jclass clazz, jint sampleRate, jint bufSize)
{
    SLresult result;
    if (sampleRate >= 0 && bufSize >= 0 ) {
        bqPlayerSampleRate_mainBeat = sampleRate * 1000;
        bqPlayerBufSize_mainBeat = bufSize;
    }

    // configure audio source
    SLDataLocator_AndroidSimpleBufferQueue in_loc;
    in_loc.locatorType = SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE;
    in_loc.numBuffers = 1;
    SLDataFormat_PCM format_pcm = {SL_DATAFORMAT_PCM, 1, SL_SAMPLINGRATE_8,
        SL_PCMSAMPLEFORMAT_FIXED_16, SL_PCMSAMPLEFORMAT_FIXED_16,
        SL_SPEAKER_FRONT_CENTER, SL_BYTEORDER_LITTLEENDIAN};

    if(bqPlayerSampleRate_mainBeat) {
        format_pcm.samplesPerSec = bqPlayerSampleRate_mainBeat;       //sample rate in mili second
    }
    SLDataSource audioSrc = {&in_loc, &format_pcm};  // link audioSrc to this buffer (in_loc)

    // configure audio OUTPUT MIX -  The player will link to this destination
    SLDataLocator_OutputMix out_loc_mainBeat_1 = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_mainBeat};  // { out_loc_mainBeat.locatorType, outputMix }
    SLDataSink destination = {&out_loc_mainBeat_1, NULL};

    // Add volume control
    const SLInterfaceID ids[] = {SL_IID_VOLUME, SL_IID_ANDROIDSIMPLEBUFFERQUEUE};
    const SLboolean req[] = {SL_BOOLEAN_TRUE, SL_BOOLEAN_TRUE};

    result = (*engine_itf_mainBeat)->CreateAudioPlayer(engine_itf_mainBeat, &buffer_obj_mainBeat_1, &audioSrc, &destination,
            bqPlayerSampleRate_mainBeat? 2 : 3, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*buffer_obj_mainBeat_1)->Realize(buffer_obj_mainBeat_1, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*buffer_obj_mainBeat_1)->GetInterface(buffer_obj_mainBeat_1, SL_IID_PLAY, &buffer_itf_mainBeat_1);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the volume interface
    result = (*buffer_obj_mainBeat_1)->GetInterface(buffer_obj_mainBeat_1, SL_IID_VOLUME, &filePlayerVolume_mainBeat_1);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the buffer queue interface
    result = (*buffer_obj_mainBeat_1)->GetInterface(buffer_obj_mainBeat_1, SL_IID_BUFFERQUEUE,
            &buf_q_mainBeat_1);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;
}

// get asset (input wav file) for the audio player
jboolean Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSoundPlayerMainBeat1(JNIEnv* env, jclass clazz,
        jobject assetManager, jstring filename)
{
    SLresult result;

    // convert Java string to UTF-8
    const char *utf8 = (*env)->GetStringUTFChars(env, filename, NULL);
    assert(NULL != utf8);

    // use asset manager to open asset by filename
    AAssetManager* mgr = AAssetManager_fromJava(env, assetManager);
    assert(NULL != mgr);
    AAsset* asset = AAssetManager_open(mgr, utf8, AASSET_MODE_UNKNOWN);

    // release the Java string and UTF-8
    (*env)->ReleaseStringUTFChars(env, filename, utf8);

    // the asset might not be found
    if (NULL == asset) {
        return JNI_FALSE;
    }

    // open asset as file descriptor
    off_t start, length;
    int fd = AAsset_openFileDescriptor(asset, &start, &length);
    assert(0 <= fd);
    AAsset_close(asset);

    // configure audio source
    SLDataLocator_AndroidFD loc_fd = {SL_DATALOCATOR_ANDROIDFD, fd, start, length};
    SLDataFormat_MIME format_mime = {SL_DATAFORMAT_MIME, NULL, SL_CONTAINERTYPE_UNSPECIFIED};
    SLDataSource audioSrc = {&loc_fd, &format_mime};

    // configure audio sink
    SLDataLocator_OutputMix out_loc = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_mainBeat};
    SLDataSink destination = {&out_loc, NULL};

    // create audio player
    const SLInterfaceID ids[] = {SL_IID_VOLUME};
    const SLboolean req[] = {SL_BOOLEAN_TRUE};
    result = (*engine_itf_mainBeat)->CreateAudioPlayer(engine_itf_mainBeat, &filePlayer_obj_mainBeat_1, &audioSrc, &destination,
            1, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*filePlayer_obj_mainBeat_1)->Realize(filePlayer_obj_mainBeat_1, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*filePlayer_obj_mainBeat_1)->GetInterface(filePlayer_obj_mainBeat_1, SL_IID_PLAY, &filePlayer_itf_mainBeat_1);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    result = (*filePlayer_obj_mainBeat_1)->GetInterface(filePlayer_obj_mainBeat_1, SL_IID_VOLUME, &filePlayerVolume_mainBeat_1);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    return JNI_TRUE;
}


// set the playing state for the asset audio player
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_setPlayStateMainBeat1(JNIEnv* env,
                                                            jclass clazz, jboolean isPlaying)
{
    SLresult result;

    // make sure the asset audio player was created
    if (NULL != filePlayer_itf_mainBeat_1) {

        // set the player's state
        result = (*filePlayer_itf_mainBeat_1)->SetPlayState(filePlayer_itf_mainBeat_1, isPlaying ?
                                                               SL_PLAYSTATE_PLAYING
                                                                         : SL_PLAYSTATE_STOPPED);
        //assert(SL_RESULT_SUCCESS == result);
        (void) result;
    }
}


// ==========================================================================================
// SECOND SET
// ==========================================================================================
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_createMainBeatAudioBuffer2(JNIEnv* env,
        jclass clazz, jint sampleRate, jint bufSize)
{
    SLresult result;
    if (sampleRate >= 0 && bufSize >= 0 ) {
        bqPlayerSampleRate_mainBeat = sampleRate * 1000;
        bqPlayerBufSize_mainBeat = bufSize;
    }

    // configure audio source
    SLDataLocator_AndroidSimpleBufferQueue in_loc;
    in_loc.locatorType = SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE;
    in_loc.numBuffers = 1;
    SLDataFormat_PCM format_pcm = {SL_DATAFORMAT_PCM, 1, SL_SAMPLINGRATE_8,
        SL_PCMSAMPLEFORMAT_FIXED_16, SL_PCMSAMPLEFORMAT_FIXED_16,
        SL_SPEAKER_FRONT_CENTER, SL_BYTEORDER_LITTLEENDIAN};

    if(bqPlayerSampleRate_mainBeat) {
        format_pcm.samplesPerSec = bqPlayerSampleRate_mainBeat;       //sample rate in mili second
    }
    SLDataSource audioSrc = {&in_loc, &format_pcm};  // link audioSrc to this buffer (in_loc)

    // configure audio OUTPUT MIX -  The player will link to this destination
    SLDataLocator_OutputMix out_loc_mainBeat_2 = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_mainBeat};  // { out_loc_mainBeat.locatorType, outputMix }
    SLDataSink destination = {&out_loc_mainBeat_2, NULL};

    // Add volume control
    const SLInterfaceID ids[] = {SL_IID_VOLUME, SL_IID_ANDROIDSIMPLEBUFFERQUEUE};
    const SLboolean req[] = {SL_BOOLEAN_TRUE, SL_BOOLEAN_TRUE};

    result = (*engine_itf_mainBeat)->CreateAudioPlayer(engine_itf_mainBeat, &buffer_obj_mainBeat_2, &audioSrc, &destination,
            bqPlayerSampleRate_mainBeat? 2 : 3, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*buffer_obj_mainBeat_2)->Realize(buffer_obj_mainBeat_2, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*buffer_obj_mainBeat_2)->GetInterface(buffer_obj_mainBeat_2, SL_IID_PLAY, &buffer_itf_mainBeat_2);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the volume interface
    result = (*buffer_obj_mainBeat_2)->GetInterface(buffer_obj_mainBeat_2, SL_IID_VOLUME, &filePlayerVolume_mainBeat_2);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the buffer queue interface
    result = (*buffer_obj_mainBeat_2)->GetInterface(buffer_obj_mainBeat_2, SL_IID_BUFFERQUEUE,
            &buf_q_mainBeat_2);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;
}

// get asset (input wav file) for the audio player
jboolean Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSoundPlayerMainBeat2(JNIEnv* env, jclass clazz,
        jobject assetManager, jstring filename)
{
    SLresult result;

    // convert Java string to UTF-8
    const char *utf8 = (*env)->GetStringUTFChars(env, filename, NULL);
    assert(NULL != utf8);

    // use asset manager to open asset by filename
    AAssetManager* mgr = AAssetManager_fromJava(env, assetManager);
    assert(NULL != mgr);
    AAsset* asset = AAssetManager_open(mgr, utf8, AASSET_MODE_UNKNOWN);

    // release the Java string and UTF-8
    (*env)->ReleaseStringUTFChars(env, filename, utf8);

    // the asset might not be found
    if (NULL == asset) {
        return JNI_FALSE;
    }

    // open asset as file descriptor
    off_t start, length;
    int fd = AAsset_openFileDescriptor(asset, &start, &length);
    assert(0 <= fd);
    AAsset_close(asset);

    // configure audio source
    SLDataLocator_AndroidFD loc_fd = {SL_DATALOCATOR_ANDROIDFD, fd, start, length};
    SLDataFormat_MIME format_mime = {SL_DATAFORMAT_MIME, NULL, SL_CONTAINERTYPE_UNSPECIFIED};
    SLDataSource audioSrc = {&loc_fd, &format_mime};

    // configure audio sink
    SLDataLocator_OutputMix out_loc = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_mainBeat};
    SLDataSink destination = {&out_loc, NULL};

    // create audio player
    const SLInterfaceID ids[] = {SL_IID_VOLUME};
    const SLboolean req[] = {SL_BOOLEAN_TRUE};
    result = (*engine_itf_mainBeat)->CreateAudioPlayer(engine_itf_mainBeat, &filePlayer_obj_mainBeat_2, &audioSrc, &destination,
            1, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*filePlayer_obj_mainBeat_2)->Realize(filePlayer_obj_mainBeat_2, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*filePlayer_obj_mainBeat_2)->GetInterface(filePlayer_obj_mainBeat_2, SL_IID_PLAY, &filePlayer_itf_mainBeat_2);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    result = (*filePlayer_obj_mainBeat_2)->GetInterface(filePlayer_obj_mainBeat_2, SL_IID_VOLUME, &filePlayerVolume_mainBeat_2);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    return JNI_TRUE;
}


// set the playing state for the asset audio player
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_setPlayStateMainBeat2(JNIEnv* env,
                                                            jclass clazz, jboolean isPlaying)
{
    SLresult result;

    // make sure the asset audio player was created
    if (NULL != filePlayer_itf_mainBeat_2) {

        // set the player's state
        result = (*filePlayer_itf_mainBeat_2)->SetPlayState(filePlayer_itf_mainBeat_2, isPlaying ?
                                                               SL_PLAYSTATE_PLAYING
                                                                         : SL_PLAYSTATE_STOPPED);
        //assert(SL_RESULT_SUCCESS == result);
        (void) result;
    }
}



// ==========================================================================================
// THIRD SET
// ==========================================================================================
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_createMainBeatAudioBuffer3(JNIEnv* env,
        jclass clazz, jint sampleRate, jint bufSize)
{
    SLresult result;
    if (sampleRate >= 0 && bufSize >= 0 ) {
        bqPlayerSampleRate_mainBeat = sampleRate * 1000;
        bqPlayerBufSize_mainBeat = bufSize;
    }

    // configure audio source
    SLDataLocator_AndroidSimpleBufferQueue in_loc;
    in_loc.locatorType = SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE;
    in_loc.numBuffers = 1;
    SLDataFormat_PCM format_pcm = {SL_DATAFORMAT_PCM, 1, SL_SAMPLINGRATE_8,
        SL_PCMSAMPLEFORMAT_FIXED_16, SL_PCMSAMPLEFORMAT_FIXED_16,
        SL_SPEAKER_FRONT_CENTER, SL_BYTEORDER_LITTLEENDIAN};

    if(bqPlayerSampleRate_mainBeat) {
        format_pcm.samplesPerSec = bqPlayerSampleRate_mainBeat;       //sample rate in mili second
    }
    SLDataSource audioSrc = {&in_loc, &format_pcm};  // link audioSrc to this buffer (in_loc)

    // configure audio OUTPUT MIX -  The player will link to this destination
    SLDataLocator_OutputMix out_loc_mainBeat_3 = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_mainBeat};  // { out_loc_mainBeat.locatorType, outputMix }
    SLDataSink destination = {&out_loc_mainBeat_3, NULL};

    // Add volume control
    const SLInterfaceID ids[] = {SL_IID_VOLUME, SL_IID_ANDROIDSIMPLEBUFFERQUEUE};
    const SLboolean req[] = {SL_BOOLEAN_TRUE, SL_BOOLEAN_TRUE};

    result = (*engine_itf_mainBeat)->CreateAudioPlayer(engine_itf_mainBeat, &buffer_obj_mainBeat_3, &audioSrc, &destination,
            bqPlayerSampleRate_mainBeat? 2 : 3, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*buffer_obj_mainBeat_3)->Realize(buffer_obj_mainBeat_3, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*buffer_obj_mainBeat_3)->GetInterface(buffer_obj_mainBeat_3, SL_IID_PLAY, &buffer_itf_mainBeat_3);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the volume interface
    result = (*buffer_obj_mainBeat_3)->GetInterface(buffer_obj_mainBeat_3, SL_IID_VOLUME, &filePlayerVolume_mainBeat_3);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the buffer queue interface
    result = (*buffer_obj_mainBeat_3)->GetInterface(buffer_obj_mainBeat_3, SL_IID_BUFFERQUEUE,
            &buf_q_mainBeat_3);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;
}

// get asset (input wav file) for the audio player
jboolean Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSoundPlayerMainBeat3(JNIEnv* env, jclass clazz,
        jobject assetManager, jstring filename)
{
    SLresult result;

    // convert Java string to UTF-8
    const char *utf8 = (*env)->GetStringUTFChars(env, filename, NULL);
    assert(NULL != utf8);

    // use asset manager to open asset by filename
    AAssetManager* mgr = AAssetManager_fromJava(env, assetManager);
    assert(NULL != mgr);
    AAsset* asset = AAssetManager_open(mgr, utf8, AASSET_MODE_UNKNOWN);

    // release the Java string and UTF-8
    (*env)->ReleaseStringUTFChars(env, filename, utf8);

    // the asset might not be found
    if (NULL == asset) {
        return JNI_FALSE;
    }

    // open asset as file descriptor
    off_t start, length;
    int fd = AAsset_openFileDescriptor(asset, &start, &length);
    assert(0 <= fd);
    AAsset_close(asset);

    // configure audio source
    SLDataLocator_AndroidFD loc_fd = {SL_DATALOCATOR_ANDROIDFD, fd, start, length};
    SLDataFormat_MIME format_mime = {SL_DATAFORMAT_MIME, NULL, SL_CONTAINERTYPE_UNSPECIFIED};
    SLDataSource audioSrc = {&loc_fd, &format_mime};

    // configure audio sink
    SLDataLocator_OutputMix out_loc = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_mainBeat};
    SLDataSink destination = {&out_loc, NULL};

    // create audio player
    const SLInterfaceID ids[] = {SL_IID_VOLUME};
    const SLboolean req[] = {SL_BOOLEAN_TRUE};
    result = (*engine_itf_mainBeat)->CreateAudioPlayer(engine_itf_mainBeat, &filePlayer_obj_mainBeat_3, &audioSrc, &destination,
            1, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*filePlayer_obj_mainBeat_3)->Realize(filePlayer_obj_mainBeat_3, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*filePlayer_obj_mainBeat_3)->GetInterface(filePlayer_obj_mainBeat_3, SL_IID_PLAY, &filePlayer_itf_mainBeat_3);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    result = (*filePlayer_obj_mainBeat_3)->GetInterface(filePlayer_obj_mainBeat_3, SL_IID_VOLUME, &filePlayerVolume_mainBeat_3);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    return JNI_TRUE;
}


// set the playing state for the asset audio player
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_setPlayStateMainBeat3(JNIEnv* env,
                                                            jclass clazz, jboolean isPlaying)
{
    SLresult result;

    // make sure the asset audio player was created
    if (NULL != filePlayer_itf_mainBeat_3) {

        // set the player's state
        result = (*filePlayer_itf_mainBeat_3)->SetPlayState(filePlayer_itf_mainBeat_3, isPlaying ?
                                                               SL_PLAYSTATE_PLAYING
                                                                         : SL_PLAYSTATE_STOPPED);
        //assert(SL_RESULT_SUCCESS == result);
        (void) result;
    }
}




// ==========================================================================================
// FOURTH SET
// ==========================================================================================
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_createMainBeatAudioBuffer4(JNIEnv* env,
        jclass clazz, jint sampleRate, jint bufSize)
{
    SLresult result;
    if (sampleRate >= 0 && bufSize >= 0 ) {
        bqPlayerSampleRate_mainBeat = sampleRate * 1000;
        bqPlayerBufSize_mainBeat = bufSize;
    }

    // configure audio source
    SLDataLocator_AndroidSimpleBufferQueue in_loc;
    in_loc.locatorType = SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE;
    in_loc.numBuffers = 1;
    SLDataFormat_PCM format_pcm = {SL_DATAFORMAT_PCM, 1, SL_SAMPLINGRATE_8,
        SL_PCMSAMPLEFORMAT_FIXED_16, SL_PCMSAMPLEFORMAT_FIXED_16,
        SL_SPEAKER_FRONT_CENTER, SL_BYTEORDER_LITTLEENDIAN};

    if(bqPlayerSampleRate_mainBeat) {
        format_pcm.samplesPerSec = bqPlayerSampleRate_mainBeat;       //sample rate in mili second
    }
    SLDataSource audioSrc = {&in_loc, &format_pcm};  // link audioSrc to this buffer (in_loc)

    // configure audio OUTPUT MIX -  The player will link to this destination
    SLDataLocator_OutputMix out_loc_mainBeat_4 = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_mainBeat};  // { out_loc_mainBeat.locatorType, outputMix }
    SLDataSink destination = {&out_loc_mainBeat_4, NULL};

    // Add volume control
    const SLInterfaceID ids[] = {SL_IID_VOLUME, SL_IID_ANDROIDSIMPLEBUFFERQUEUE};
    const SLboolean req[] = {SL_BOOLEAN_TRUE, SL_BOOLEAN_TRUE};

    result = (*engine_itf_mainBeat)->CreateAudioPlayer(engine_itf_mainBeat, &buffer_obj_mainBeat_4, &audioSrc, &destination,
            bqPlayerSampleRate_mainBeat? 2 : 3, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*buffer_obj_mainBeat_4)->Realize(buffer_obj_mainBeat_4, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*buffer_obj_mainBeat_4)->GetInterface(buffer_obj_mainBeat_4, SL_IID_PLAY, &buffer_itf_mainBeat_4);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the volume interface
    result = (*buffer_obj_mainBeat_4)->GetInterface(buffer_obj_mainBeat_4, SL_IID_VOLUME, &filePlayerVolume_mainBeat_4);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the buffer queue interface
    result = (*buffer_obj_mainBeat_4)->GetInterface(buffer_obj_mainBeat_4, SL_IID_BUFFERQUEUE,
            &buf_q_mainBeat_4);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;
}

// get asset (input wav file) for the audio player
jboolean Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSoundPlayerMainBeat4(JNIEnv* env, jclass clazz,
        jobject assetManager, jstring filename)
{
    SLresult result;

    // convert Java string to UTF-8
    const char *utf8 = (*env)->GetStringUTFChars(env, filename, NULL);
    assert(NULL != utf8);

    // use asset manager to open asset by filename
    AAssetManager* mgr = AAssetManager_fromJava(env, assetManager);
    assert(NULL != mgr);
    AAsset* asset = AAssetManager_open(mgr, utf8, AASSET_MODE_UNKNOWN);

    // release the Java string and UTF-8
    (*env)->ReleaseStringUTFChars(env, filename, utf8);

    // the asset might not be found
    if (NULL == asset) {
        return JNI_FALSE;
    }

    // open asset as file descriptor
    off_t start, length;
    int fd = AAsset_openFileDescriptor(asset, &start, &length);
    assert(0 <= fd);
    AAsset_close(asset);

    // configure audio source
    SLDataLocator_AndroidFD loc_fd = {SL_DATALOCATOR_ANDROIDFD, fd, start, length};
    SLDataFormat_MIME format_mime = {SL_DATAFORMAT_MIME, NULL, SL_CONTAINERTYPE_UNSPECIFIED};
    SLDataSource audioSrc = {&loc_fd, &format_mime};

    // configure audio sink
    SLDataLocator_OutputMix out_loc = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_mainBeat};
    SLDataSink destination = {&out_loc, NULL};

    // create audio player
    const SLInterfaceID ids[] = {SL_IID_VOLUME};
    const SLboolean req[] = {SL_BOOLEAN_TRUE};
    result = (*engine_itf_mainBeat)->CreateAudioPlayer(engine_itf_mainBeat, &filePlayer_obj_mainBeat_4, &audioSrc, &destination,
            1, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*filePlayer_obj_mainBeat_4)->Realize(filePlayer_obj_mainBeat_4, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*filePlayer_obj_mainBeat_4)->GetInterface(filePlayer_obj_mainBeat_4, SL_IID_PLAY, &filePlayer_itf_mainBeat_4);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    result = (*filePlayer_obj_mainBeat_4)->GetInterface(filePlayer_obj_mainBeat_4, SL_IID_VOLUME, &filePlayerVolume_mainBeat_4);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    return JNI_TRUE;
}


// set the playing state for the asset audio player
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_setPlayStateMainBeat4(JNIEnv* env,
                                                            jclass clazz, jboolean isPlaying)
{
    SLresult result;

    // make sure the asset audio player was created
    if (NULL != filePlayer_itf_mainBeat_4) {

        // set the player's state
        result = (*filePlayer_itf_mainBeat_4)->SetPlayState(filePlayer_itf_mainBeat_4, isPlaying ?
                                                               SL_PLAYSTATE_PLAYING
                                                                         : SL_PLAYSTATE_STOPPED);
        //assert(SL_RESULT_SUCCESS == result);
        (void) result;
    }
}




// ==========================================================================================
// FIFTH SET
// ==========================================================================================
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_createMainBeatAudioBuffer5(JNIEnv* env,
        jclass clazz, jint sampleRate, jint bufSize)
{
    SLresult result;
    if (sampleRate >= 0 && bufSize >= 0 ) {
        bqPlayerSampleRate_mainBeat = sampleRate * 1000;
        bqPlayerBufSize_mainBeat = bufSize;
    }

    // configure audio source
    SLDataLocator_AndroidSimpleBufferQueue in_loc;
    in_loc.locatorType = SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE;
    in_loc.numBuffers = 1;
    SLDataFormat_PCM format_pcm = {SL_DATAFORMAT_PCM, 1, SL_SAMPLINGRATE_8,
        SL_PCMSAMPLEFORMAT_FIXED_16, SL_PCMSAMPLEFORMAT_FIXED_16,
        SL_SPEAKER_FRONT_CENTER, SL_BYTEORDER_LITTLEENDIAN};

    if(bqPlayerSampleRate_mainBeat) {
        format_pcm.samplesPerSec = bqPlayerSampleRate_mainBeat;       //sample rate in mili second
    }
    SLDataSource audioSrc = {&in_loc, &format_pcm};  // link audioSrc to this buffer (in_loc)

    // configure audio OUTPUT MIX -  The player will link to this destination
    SLDataLocator_OutputMix out_loc_mainBeat_5 = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_mainBeat};  // { out_loc_mainBeat.locatorType, outputMix }
    SLDataSink destination = {&out_loc_mainBeat_5, NULL};

    // Add volume control
    const SLInterfaceID ids[] = {SL_IID_VOLUME, SL_IID_ANDROIDSIMPLEBUFFERQUEUE};
    const SLboolean req[] = {SL_BOOLEAN_TRUE, SL_BOOLEAN_TRUE};

    result = (*engine_itf_mainBeat)->CreateAudioPlayer(engine_itf_mainBeat, &buffer_obj_mainBeat_5, &audioSrc, &destination,
            bqPlayerSampleRate_mainBeat? 2 : 3, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*buffer_obj_mainBeat_5)->Realize(buffer_obj_mainBeat_5, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*buffer_obj_mainBeat_5)->GetInterface(buffer_obj_mainBeat_5, SL_IID_PLAY, &buffer_itf_mainBeat_5);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the volume interface
    result = (*buffer_obj_mainBeat_5)->GetInterface(buffer_obj_mainBeat_5, SL_IID_VOLUME, &filePlayerVolume_mainBeat_5);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the buffer queue interface
    result = (*buffer_obj_mainBeat_5)->GetInterface(buffer_obj_mainBeat_5, SL_IID_BUFFERQUEUE,
            &buf_q_mainBeat_5);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;
}

// get asset (input wav file) for the audio player
jboolean Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSoundPlayerMainBeat5(JNIEnv* env, jclass clazz,
        jobject assetManager, jstring filename)
{
    SLresult result;

    // convert Java string to UTF-8
    const char *utf8 = (*env)->GetStringUTFChars(env, filename, NULL);
    assert(NULL != utf8);

    // use asset manager to open asset by filename
    AAssetManager* mgr = AAssetManager_fromJava(env, assetManager);
    assert(NULL != mgr);
    AAsset* asset = AAssetManager_open(mgr, utf8, AASSET_MODE_UNKNOWN);

    // release the Java string and UTF-8
    (*env)->ReleaseStringUTFChars(env, filename, utf8);

    // the asset might not be found
    if (NULL == asset) {
        return JNI_FALSE;
    }

    // open asset as file descriptor
    off_t start, length;
    int fd = AAsset_openFileDescriptor(asset, &start, &length);
    assert(0 <= fd);
    AAsset_close(asset);

    // configure audio source
    SLDataLocator_AndroidFD loc_fd = {SL_DATALOCATOR_ANDROIDFD, fd, start, length};
    SLDataFormat_MIME format_mime = {SL_DATAFORMAT_MIME, NULL, SL_CONTAINERTYPE_UNSPECIFIED};
    SLDataSource audioSrc = {&loc_fd, &format_mime};

    // configure audio sink
    SLDataLocator_OutputMix out_loc = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_mainBeat};
    SLDataSink destination = {&out_loc, NULL};

    // create audio player
    const SLInterfaceID ids[] = {SL_IID_VOLUME};
    const SLboolean req[] = {SL_BOOLEAN_TRUE};
    result = (*engine_itf_mainBeat)->CreateAudioPlayer(engine_itf_mainBeat, &filePlayer_obj_mainBeat_5, &audioSrc, &destination,
            1, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*filePlayer_obj_mainBeat_5)->Realize(filePlayer_obj_mainBeat_5, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*filePlayer_obj_mainBeat_5)->GetInterface(filePlayer_obj_mainBeat_5, SL_IID_PLAY, &filePlayer_itf_mainBeat_5);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    result = (*filePlayer_obj_mainBeat_5)->GetInterface(filePlayer_obj_mainBeat_5, SL_IID_VOLUME, &filePlayerVolume_mainBeat_5);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    return JNI_TRUE;
}


// set the playing state for the asset audio player
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_setPlayStateMainBeat5(JNIEnv* env,
                                                            jclass clazz, jboolean isPlaying)
{
    SLresult result;

    // make sure the asset audio player was created
    if (NULL != filePlayer_itf_mainBeat_5) {

        // set the player's state
        result = (*filePlayer_itf_mainBeat_5)->SetPlayState(filePlayer_itf_mainBeat_5, isPlaying ?
                                                               SL_PLAYSTATE_PLAYING
                                                                         : SL_PLAYSTATE_STOPPED);
        //assert(SL_RESULT_SUCCESS == result);
        (void) result;
    }
}


// ================================================
// ================================================
//       SUB BEAT CODE SECTION
// ================================================
// ================================================

void releaseresampleBuf_subBeat(void) {
    if( 0 == bqPlayerSampleRate_subBeat) {
        return;
    }
    free(resampleBuf_subBeat);
    resampleBuf_subBeat = NULL;
}

// create the engine and output mix objects
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSubBeatEngine(JNIEnv* env, jclass clazz)
{
    SLresult result;

    // create engine
    result = slCreateEngine(&engine_object_subBeat, 0, NULL, 0, NULL, NULL);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the engine
    result = (*engine_object_subBeat)->Realize(engine_object_subBeat, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the engine interface, which is needed in order to create other objects
    result = (*engine_object_subBeat)->GetInterface(engine_object_subBeat, SL_IID_ENGINE, &engine_itf_subBeat);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // create output mix with volume interface
    const SLInterfaceID ids[] = { SL_IID_VOLUME };
    const SLboolean req[] = { SL_BOOLEAN_FALSE };
    result = (*engine_itf_subBeat)->CreateOutputMix(engine_itf_subBeat, &output_MixObject_subBeat, 1, ids, req );
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the output mix
    result = (*output_MixObject_subBeat)->Realize(output_MixObject_subBeat, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    if( (*output_MixObject_subBeat)->GetInterface( output_MixObject_subBeat,
                                                    SL_IID_VOLUME, &output_MixObject_vol_subBeat ) != SL_RESULT_SUCCESS )
        output_MixObject_vol_subBeat = NULL;
}


//===========================================================================================
//  FIRST SET
//===========================================================================================
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSubBeatAudioBuffer1(JNIEnv* env,
                                                                                  jclass clazz, jint sampleRate, jint bufSize)
{
    SLresult result;
    if (sampleRate >= 0 && bufSize >= 0 ) {
        bqPlayerSampleRate_subBeat = sampleRate * 1000;
        bqPlayerBufSize_subBeat = bufSize;
    }

    // configure audio source
    SLDataLocator_AndroidSimpleBufferQueue in_loc;
    in_loc.locatorType = SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE;
    in_loc.numBuffers = 1;
    SLDataFormat_PCM format_pcm = {SL_DATAFORMAT_PCM, 1, SL_SAMPLINGRATE_8,
                                   SL_PCMSAMPLEFORMAT_FIXED_16, SL_PCMSAMPLEFORMAT_FIXED_16,
                                   SL_SPEAKER_FRONT_CENTER, SL_BYTEORDER_LITTLEENDIAN};

    if(bqPlayerSampleRate_subBeat) {
        format_pcm.samplesPerSec = bqPlayerSampleRate_subBeat;       //sample rate in mili second
    }
    SLDataSource audioSrc = {&in_loc, &format_pcm};  // link audioSrc to this buffer (in_loc)

    // configure audio OUTPUT MIX -  The player will link to this destination
    SLDataLocator_OutputMix out_loc_SubBeat_1 = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_subBeat};  // { out_loc_SubBeat.locatorType, outputMix }
    SLDataSink destination = {&out_loc_SubBeat_1, NULL};

    // Add volume control
    const SLInterfaceID ids[] = {SL_IID_VOLUME, SL_IID_ANDROIDSIMPLEBUFFERQUEUE};
    const SLboolean req[] = {SL_BOOLEAN_TRUE, SL_BOOLEAN_TRUE};

    result = (*engine_itf_subBeat)->CreateAudioPlayer(engine_itf_subBeat, &buffer_obj_subBeat_1, &audioSrc, &destination,
                                                       bqPlayerSampleRate_subBeat? 2 : 3, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*buffer_obj_subBeat_1)->Realize(buffer_obj_subBeat_1, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*buffer_obj_subBeat_1)->GetInterface(buffer_obj_subBeat_1, SL_IID_PLAY, &buffer_itf_subBeat_1);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the volume interface
    result = (*buffer_obj_subBeat_1)->GetInterface(buffer_obj_subBeat_1, SL_IID_VOLUME, &filePlayerVolume_subBeat_1);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the buffer queue interface
    result = (*buffer_obj_subBeat_1)->GetInterface(buffer_obj_subBeat_1, SL_IID_BUFFERQUEUE,
                                                    &buf_q_subBeat_1);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;
}

// get asset (input wav file) for the audio player
jboolean Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSoundPlayerSubBeat1(JNIEnv* env, jclass clazz,
                                                                                      jobject assetManager, jstring filename)
{
    SLresult result;

    // convert Java string to UTF-8
    const char *utf8 = (*env)->GetStringUTFChars(env, filename, NULL);
    assert(NULL != utf8);

    // use asset manager to open asset by filename
    AAssetManager* mgr = AAssetManager_fromJava(env, assetManager);
    assert(NULL != mgr);
    AAsset* asset = AAssetManager_open(mgr, utf8, AASSET_MODE_UNKNOWN);

    // release the Java string and UTF-8
    (*env)->ReleaseStringUTFChars(env, filename, utf8);

    // the asset might not be found
    if (NULL == asset) {
        return JNI_FALSE;
    }

    // open asset as file descriptor
    off_t start, length;
    int fd = AAsset_openFileDescriptor(asset, &start, &length);
    assert(0 <= fd);
    AAsset_close(asset);

    // configure audio source
    SLDataLocator_AndroidFD loc_fd = {SL_DATALOCATOR_ANDROIDFD, fd, start, length};
    SLDataFormat_MIME format_mime = {SL_DATAFORMAT_MIME, NULL, SL_CONTAINERTYPE_UNSPECIFIED};
    SLDataSource audioSrc = {&loc_fd, &format_mime};

    // configure audio sink
    SLDataLocator_OutputMix out_loc = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_subBeat};
    SLDataSink destination = {&out_loc, NULL};

    // create audio player
    const SLInterfaceID ids[] = {SL_IID_VOLUME};
    const SLboolean req[] = {SL_BOOLEAN_TRUE};
    result = (*engine_itf_subBeat)->CreateAudioPlayer(engine_itf_subBeat, &filePlayer_obj_subBeat_1, &audioSrc, &destination,
                                                       1, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*filePlayer_obj_subBeat_1)->Realize(filePlayer_obj_subBeat_1, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*filePlayer_obj_subBeat_1)->GetInterface(filePlayer_obj_subBeat_1, SL_IID_PLAY, &filePlayer_itf_subBeat_1);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    result = (*filePlayer_obj_subBeat_1)->GetInterface(filePlayer_obj_subBeat_1, SL_IID_VOLUME, &filePlayerVolume_subBeat_1);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    return JNI_TRUE;
}


// set the playing state for the asset audio player
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_setPlayStateSubBeat1(JNIEnv* env,
                                                                             jclass clazz, jboolean isPlaying)
{
    SLresult result;

    // make sure the asset audio player was created
    if (NULL != filePlayer_itf_subBeat_1) {

        // set the player's state
        result = (*filePlayer_itf_subBeat_1)->SetPlayState(filePlayer_itf_subBeat_1, isPlaying ?
                                                                                       SL_PLAYSTATE_PLAYING
                                                                                                 : SL_PLAYSTATE_STOPPED);
        //assert(SL_RESULT_SUCCESS == result);
        (void) result;
    }
}



// ==========================================================================================
// SECOND SET
// ==========================================================================================
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSubBeatAudioBuffer2(JNIEnv* env,
                                                                                 jclass clazz, jint sampleRate, jint bufSize)
{
    SLresult result;
    if (sampleRate >= 0 && bufSize >= 0 ) {
        bqPlayerSampleRate_subBeat = sampleRate * 1000;
        bqPlayerBufSize_subBeat = bufSize;
    }

    // configure audio source
    SLDataLocator_AndroidSimpleBufferQueue in_loc;
    in_loc.locatorType = SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE;
    in_loc.numBuffers = 1;
    SLDataFormat_PCM format_pcm = {SL_DATAFORMAT_PCM, 1, SL_SAMPLINGRATE_8,
                                   SL_PCMSAMPLEFORMAT_FIXED_16, SL_PCMSAMPLEFORMAT_FIXED_16,
                                   SL_SPEAKER_FRONT_CENTER, SL_BYTEORDER_LITTLEENDIAN};

    if(bqPlayerSampleRate_subBeat) {
        format_pcm.samplesPerSec = bqPlayerSampleRate_subBeat;       //sample rate in mili second
    }
    SLDataSource audioSrc = {&in_loc, &format_pcm};  // link audioSrc to this buffer (in_loc)

    // configure audio OUTPUT MIX -  The player will link to this destination
    SLDataLocator_OutputMix out_loc_SubBeat_2 = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_subBeat};  // { out_loc_SubBeat.locatorType, outputMix }
    SLDataSink destination = {&out_loc_SubBeat_2, NULL};

    // Add volume control
    const SLInterfaceID ids[] = {SL_IID_VOLUME, SL_IID_ANDROIDSIMPLEBUFFERQUEUE};
    const SLboolean req[] = {SL_BOOLEAN_TRUE, SL_BOOLEAN_TRUE};

    result = (*engine_itf_subBeat)->CreateAudioPlayer(engine_itf_subBeat, &buffer_obj_subBeat_2, &audioSrc, &destination,
                                                      bqPlayerSampleRate_subBeat? 2 : 3, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*buffer_obj_subBeat_2)->Realize(buffer_obj_subBeat_2, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*buffer_obj_subBeat_2)->GetInterface(buffer_obj_subBeat_2, SL_IID_PLAY, &buffer_itf_subBeat_2);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the volume interface
    result = (*buffer_obj_subBeat_2)->GetInterface(buffer_obj_subBeat_2, SL_IID_VOLUME, &filePlayerVolume_subBeat_2);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the buffer queue interface
    result = (*buffer_obj_subBeat_2)->GetInterface(buffer_obj_subBeat_2, SL_IID_BUFFERQUEUE,
                                                   &buf_q_subBeat_2);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;
}

// get asset (input wav file) for the audio player
jboolean Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSoundPlayerSubBeat2(JNIEnv* env, jclass clazz,
                                                                                     jobject assetManager, jstring filename)
{
    SLresult result;

    // convert Java string to UTF-8
    const char *utf8 = (*env)->GetStringUTFChars(env, filename, NULL);
    assert(NULL != utf8);

    // use asset manager to open asset by filename
    AAssetManager* mgr = AAssetManager_fromJava(env, assetManager);
    assert(NULL != mgr);
    AAsset* asset = AAssetManager_open(mgr, utf8, AASSET_MODE_UNKNOWN);

    // release the Java string and UTF-8
    (*env)->ReleaseStringUTFChars(env, filename, utf8);

    // the asset might not be found
    if (NULL == asset) {
        return JNI_FALSE;
    }

    // open asset as file descriptor
    off_t start, length;
    int fd = AAsset_openFileDescriptor(asset, &start, &length);
    assert(0 <= fd);
    AAsset_close(asset);

    // configure audio source
    SLDataLocator_AndroidFD loc_fd = {SL_DATALOCATOR_ANDROIDFD, fd, start, length};
    SLDataFormat_MIME format_mime = {SL_DATAFORMAT_MIME, NULL, SL_CONTAINERTYPE_UNSPECIFIED};
    SLDataSource audioSrc = {&loc_fd, &format_mime};

    // configure audio sink
    SLDataLocator_OutputMix out_loc = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_subBeat};
    SLDataSink destination = {&out_loc, NULL};

    // create audio player
    const SLInterfaceID ids[] = {SL_IID_VOLUME};
    const SLboolean req[] = {SL_BOOLEAN_TRUE};
    result = (*engine_itf_subBeat)->CreateAudioPlayer(engine_itf_subBeat, &filePlayer_obj_subBeat_2, &audioSrc, &destination,
                                                      1, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*filePlayer_obj_subBeat_2)->Realize(filePlayer_obj_subBeat_2, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*filePlayer_obj_subBeat_2)->GetInterface(filePlayer_obj_subBeat_2, SL_IID_PLAY, &filePlayer_itf_subBeat_2);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    result = (*filePlayer_obj_subBeat_2)->GetInterface(filePlayer_obj_subBeat_2, SL_IID_VOLUME, &filePlayerVolume_subBeat_2);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    return JNI_TRUE;
}


// set the playing state for the asset audio player
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_setPlayStateSubBeat2(JNIEnv* env,
                                                                            jclass clazz, jboolean isPlaying)
{
    SLresult result;

    // make sure the asset audio player was created
    if (NULL != filePlayer_itf_subBeat_2) {

        // set the player's state
        result = (*filePlayer_itf_subBeat_2)->SetPlayState(filePlayer_itf_subBeat_2, isPlaying ?
                                                                                     SL_PLAYSTATE_PLAYING
                                                                                               : SL_PLAYSTATE_STOPPED);
        //assert(SL_RESULT_SUCCESS == result);
        (void) result;
    }
}


// ==========================================================================================
// THIRD SET
// ==========================================================================================
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSubBeatAudioBuffer3(JNIEnv* env,
                                                                                 jclass clazz, jint sampleRate, jint bufSize)
{
    SLresult result;
    if (sampleRate >= 0 && bufSize >= 0 ) {
        bqPlayerSampleRate_subBeat = sampleRate * 1000;
        bqPlayerBufSize_subBeat = bufSize;
    }

    // configure audio source
    SLDataLocator_AndroidSimpleBufferQueue in_loc;
    in_loc.locatorType = SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE;
    in_loc.numBuffers = 1;
    SLDataFormat_PCM format_pcm = {SL_DATAFORMAT_PCM, 1, SL_SAMPLINGRATE_8,
                                   SL_PCMSAMPLEFORMAT_FIXED_16, SL_PCMSAMPLEFORMAT_FIXED_16,
                                   SL_SPEAKER_FRONT_CENTER, SL_BYTEORDER_LITTLEENDIAN};

    if(bqPlayerSampleRate_subBeat) {
        format_pcm.samplesPerSec = bqPlayerSampleRate_subBeat;       //sample rate in mili second
    }
    SLDataSource audioSrc = {&in_loc, &format_pcm};  // link audioSrc to this buffer (in_loc)

    // configure audio OUTPUT MIX -  The player will link to this destination
    SLDataLocator_OutputMix out_loc_SubBeat_3 = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_subBeat};  // { out_loc_SubBeat.locatorType, outputMix }
    SLDataSink destination = {&out_loc_SubBeat_3, NULL};

    // Add volume control
    const SLInterfaceID ids[] = {SL_IID_VOLUME, SL_IID_ANDROIDSIMPLEBUFFERQUEUE};
    const SLboolean req[] = {SL_BOOLEAN_TRUE, SL_BOOLEAN_TRUE};

    result = (*engine_itf_subBeat)->CreateAudioPlayer(engine_itf_subBeat, &buffer_obj_subBeat_3, &audioSrc, &destination,
                                                      bqPlayerSampleRate_subBeat? 2 : 3, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*buffer_obj_subBeat_3)->Realize(buffer_obj_subBeat_3, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*buffer_obj_subBeat_3)->GetInterface(buffer_obj_subBeat_3, SL_IID_PLAY, &buffer_itf_subBeat_3);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the volume interface
    result = (*buffer_obj_subBeat_3)->GetInterface(buffer_obj_subBeat_3, SL_IID_VOLUME, &filePlayerVolume_subBeat_3);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the buffer queue interface
    result = (*buffer_obj_subBeat_3)->GetInterface(buffer_obj_subBeat_3, SL_IID_BUFFERQUEUE,
                                                   &buf_q_subBeat_3);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;
}

// get asset (input wav file) for the audio player
jboolean Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSoundPlayerSubBeat3(JNIEnv* env, jclass clazz,
                                                                                     jobject assetManager, jstring filename)
{
    SLresult result;

    // convert Java string to UTF-8
    const char *utf8 = (*env)->GetStringUTFChars(env, filename, NULL);
    assert(NULL != utf8);

    // use asset manager to open asset by filename
    AAssetManager* mgr = AAssetManager_fromJava(env, assetManager);
    assert(NULL != mgr);
    AAsset* asset = AAssetManager_open(mgr, utf8, AASSET_MODE_UNKNOWN);

    // release the Java string and UTF-8
    (*env)->ReleaseStringUTFChars(env, filename, utf8);

    // the asset might not be found
    if (NULL == asset) {
        return JNI_FALSE;
    }

    // open asset as file descriptor
    off_t start, length;
    int fd = AAsset_openFileDescriptor(asset, &start, &length);
    assert(0 <= fd);
    AAsset_close(asset);

    // configure audio source
    SLDataLocator_AndroidFD loc_fd = {SL_DATALOCATOR_ANDROIDFD, fd, start, length};
    SLDataFormat_MIME format_mime = {SL_DATAFORMAT_MIME, NULL, SL_CONTAINERTYPE_UNSPECIFIED};
    SLDataSource audioSrc = {&loc_fd, &format_mime};

    // configure audio sink
    SLDataLocator_OutputMix out_loc = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_subBeat};
    SLDataSink destination = {&out_loc, NULL};

    // create audio player
    const SLInterfaceID ids[] = {SL_IID_VOLUME};
    const SLboolean req[] = {SL_BOOLEAN_TRUE};
    result = (*engine_itf_subBeat)->CreateAudioPlayer(engine_itf_subBeat, &filePlayer_obj_subBeat_3, &audioSrc, &destination,
                                                      1, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*filePlayer_obj_subBeat_3)->Realize(filePlayer_obj_subBeat_3, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*filePlayer_obj_subBeat_3)->GetInterface(filePlayer_obj_subBeat_3, SL_IID_PLAY, &filePlayer_itf_subBeat_3);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    result = (*filePlayer_obj_subBeat_3)->GetInterface(filePlayer_obj_subBeat_3, SL_IID_VOLUME, &filePlayerVolume_subBeat_3);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    return JNI_TRUE;
}


// set the playing state for the asset audio player
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_setPlayStateSubBeat3(JNIEnv* env,
                                                                            jclass clazz, jboolean isPlaying)
{
    SLresult result;

    // make sure the asset audio player was created
    if (NULL != filePlayer_itf_subBeat_3) {

        // set the player's state
        result = (*filePlayer_itf_subBeat_3)->SetPlayState(filePlayer_itf_subBeat_3, isPlaying ?
                                                                                     SL_PLAYSTATE_PLAYING
                                                                                               : SL_PLAYSTATE_STOPPED);
        //assert(SL_RESULT_SUCCESS == result);
        (void) result;
    }
}


// ==========================================================================================
// FOURTH SET
// ==========================================================================================
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSubBeatAudioBuffer4(JNIEnv* env,
                                                                                 jclass clazz, jint sampleRate, jint bufSize)
{
    SLresult result;
    if (sampleRate >= 0 && bufSize >= 0 ) {
        bqPlayerSampleRate_subBeat = sampleRate * 1000;
        bqPlayerBufSize_subBeat = bufSize;
    }

    // configure audio source
    SLDataLocator_AndroidSimpleBufferQueue in_loc;
    in_loc.locatorType = SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE;
    in_loc.numBuffers = 1;
    SLDataFormat_PCM format_pcm = {SL_DATAFORMAT_PCM, 1, SL_SAMPLINGRATE_8,
                                   SL_PCMSAMPLEFORMAT_FIXED_16, SL_PCMSAMPLEFORMAT_FIXED_16,
                                   SL_SPEAKER_FRONT_CENTER, SL_BYTEORDER_LITTLEENDIAN};

    if(bqPlayerSampleRate_subBeat) {
        format_pcm.samplesPerSec = bqPlayerSampleRate_subBeat;       //sample rate in mili second
    }
    SLDataSource audioSrc = {&in_loc, &format_pcm};  // link audioSrc to this buffer (in_loc)

    // configure audio OUTPUT MIX -  The player will link to this destination
    SLDataLocator_OutputMix out_loc_SubBeat_4 = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_subBeat};  // { out_loc_SubBeat.locatorType, outputMix }
    SLDataSink destination = {&out_loc_SubBeat_4, NULL};

    // Add volume control
    const SLInterfaceID ids[] = {SL_IID_VOLUME, SL_IID_ANDROIDSIMPLEBUFFERQUEUE};
    const SLboolean req[] = {SL_BOOLEAN_TRUE, SL_BOOLEAN_TRUE};

    result = (*engine_itf_subBeat)->CreateAudioPlayer(engine_itf_subBeat, &buffer_obj_subBeat_4, &audioSrc, &destination,
                                                      bqPlayerSampleRate_subBeat? 2 : 3, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*buffer_obj_subBeat_4)->Realize(buffer_obj_subBeat_4, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*buffer_obj_subBeat_4)->GetInterface(buffer_obj_subBeat_4, SL_IID_PLAY, &buffer_itf_subBeat_4);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the volume interface
    result = (*buffer_obj_subBeat_4)->GetInterface(buffer_obj_subBeat_4, SL_IID_VOLUME, &filePlayerVolume_subBeat_4);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the buffer queue interface
    result = (*buffer_obj_subBeat_4)->GetInterface(buffer_obj_subBeat_4, SL_IID_BUFFERQUEUE,
                                                   &buf_q_subBeat_4);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;
}

// get asset (input wav file) for the audio player
jboolean Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSoundPlayerSubBeat4(JNIEnv* env, jclass clazz,
                                                                                     jobject assetManager, jstring filename)
{
    SLresult result;

    // convert Java string to UTF-8
    const char *utf8 = (*env)->GetStringUTFChars(env, filename, NULL);
    assert(NULL != utf8);

    // use asset manager to open asset by filename
    AAssetManager* mgr = AAssetManager_fromJava(env, assetManager);
    assert(NULL != mgr);
    AAsset* asset = AAssetManager_open(mgr, utf8, AASSET_MODE_UNKNOWN);

    // release the Java string and UTF-8
    (*env)->ReleaseStringUTFChars(env, filename, utf8);

    // the asset might not be found
    if (NULL == asset) {
        return JNI_FALSE;
    }

    // open asset as file descriptor
    off_t start, length;
    int fd = AAsset_openFileDescriptor(asset, &start, &length);
    assert(0 <= fd);
    AAsset_close(asset);

    // configure audio source
    SLDataLocator_AndroidFD loc_fd = {SL_DATALOCATOR_ANDROIDFD, fd, start, length};
    SLDataFormat_MIME format_mime = {SL_DATAFORMAT_MIME, NULL, SL_CONTAINERTYPE_UNSPECIFIED};
    SLDataSource audioSrc = {&loc_fd, &format_mime};

    // configure audio sink
    SLDataLocator_OutputMix out_loc = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_subBeat};
    SLDataSink destination = {&out_loc, NULL};

    // create audio player
    const SLInterfaceID ids[] = {SL_IID_VOLUME};
    const SLboolean req[] = {SL_BOOLEAN_TRUE};
    result = (*engine_itf_subBeat)->CreateAudioPlayer(engine_itf_subBeat, &filePlayer_obj_subBeat_4, &audioSrc, &destination,
                                                      1, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*filePlayer_obj_subBeat_4)->Realize(filePlayer_obj_subBeat_4, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*filePlayer_obj_subBeat_4)->GetInterface(filePlayer_obj_subBeat_4, SL_IID_PLAY, &filePlayer_itf_subBeat_4);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    result = (*filePlayer_obj_subBeat_4)->GetInterface(filePlayer_obj_subBeat_4, SL_IID_VOLUME, &filePlayerVolume_subBeat_4);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    return JNI_TRUE;
}


// set the playing state for the asset audio player
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_setPlayStateSubBeat4(JNIEnv* env,
                                                                            jclass clazz, jboolean isPlaying)
{
    SLresult result;

    // make sure the asset audio player was created
    if (NULL != filePlayer_itf_subBeat_4) {

        // set the player's state
        result = (*filePlayer_itf_subBeat_4)->SetPlayState(filePlayer_itf_subBeat_4, isPlaying ?
                                                                                     SL_PLAYSTATE_PLAYING
                                                                                               : SL_PLAYSTATE_STOPPED);
        //assert(SL_RESULT_SUCCESS == result);
        (void) result;
    }
}


// ==========================================================================================
// FIFTH SET
// ==========================================================================================
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSubBeatAudioBuffer5(JNIEnv* env,
                                                                                 jclass clazz, jint sampleRate, jint bufSize)
{
    SLresult result;
    if (sampleRate >= 0 && bufSize >= 0 ) {
        bqPlayerSampleRate_subBeat = sampleRate * 1000;
        bqPlayerBufSize_subBeat = bufSize;
    }

    // configure audio source
    SLDataLocator_AndroidSimpleBufferQueue in_loc;
    in_loc.locatorType = SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE;
    in_loc.numBuffers = 1;
    SLDataFormat_PCM format_pcm = {SL_DATAFORMAT_PCM, 1, SL_SAMPLINGRATE_8,
                                   SL_PCMSAMPLEFORMAT_FIXED_16, SL_PCMSAMPLEFORMAT_FIXED_16,
                                   SL_SPEAKER_FRONT_CENTER, SL_BYTEORDER_LITTLEENDIAN};

    if(bqPlayerSampleRate_subBeat) {
        format_pcm.samplesPerSec = bqPlayerSampleRate_subBeat;       //sample rate in mili second
    }
    SLDataSource audioSrc = {&in_loc, &format_pcm};  // link audioSrc to this buffer (in_loc)

    // configure audio OUTPUT MIX -  The player will link to this destination
    SLDataLocator_OutputMix out_loc_SubBeat_5 = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_subBeat};  // { out_loc_SubBeat.locatorType, outputMix }
    SLDataSink destination = {&out_loc_SubBeat_5, NULL};

    // Add volume control
    const SLInterfaceID ids[] = {SL_IID_VOLUME, SL_IID_ANDROIDSIMPLEBUFFERQUEUE};
    const SLboolean req[] = {SL_BOOLEAN_TRUE, SL_BOOLEAN_TRUE};

    result = (*engine_itf_subBeat)->CreateAudioPlayer(engine_itf_subBeat, &buffer_obj_subBeat_5, &audioSrc, &destination,
                                                      bqPlayerSampleRate_subBeat? 2 : 3, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*buffer_obj_subBeat_5)->Realize(buffer_obj_subBeat_5, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*buffer_obj_subBeat_5)->GetInterface(buffer_obj_subBeat_5, SL_IID_PLAY, &buffer_itf_subBeat_5);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the volume interface
    result = (*buffer_obj_subBeat_5)->GetInterface(buffer_obj_subBeat_5, SL_IID_VOLUME, &filePlayerVolume_subBeat_5);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the buffer queue interface
    result = (*buffer_obj_subBeat_5)->GetInterface(buffer_obj_subBeat_5, SL_IID_BUFFERQUEUE,
                                                   &buf_q_subBeat_5);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;
}

// get asset (input wav file) for the audio player
jboolean Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSoundPlayerSubBeat5(JNIEnv* env, jclass clazz,
                                                                                     jobject assetManager, jstring filename)
{
    SLresult result;

    // convert Java string to UTF-8
    const char *utf8 = (*env)->GetStringUTFChars(env, filename, NULL);
    assert(NULL != utf8);

    // use asset manager to open asset by filename
    AAssetManager* mgr = AAssetManager_fromJava(env, assetManager);
    assert(NULL != mgr);
    AAsset* asset = AAssetManager_open(mgr, utf8, AASSET_MODE_UNKNOWN);

    // release the Java string and UTF-8
    (*env)->ReleaseStringUTFChars(env, filename, utf8);

    // the asset might not be found
    if (NULL == asset) {
        return JNI_FALSE;
    }

    // open asset as file descriptor
    off_t start, length;
    int fd = AAsset_openFileDescriptor(asset, &start, &length);
    assert(0 <= fd);
    AAsset_close(asset);

    // configure audio source
    SLDataLocator_AndroidFD loc_fd = {SL_DATALOCATOR_ANDROIDFD, fd, start, length};
    SLDataFormat_MIME format_mime = {SL_DATAFORMAT_MIME, NULL, SL_CONTAINERTYPE_UNSPECIFIED};
    SLDataSource audioSrc = {&loc_fd, &format_mime};

    // configure audio sink
    SLDataLocator_OutputMix out_loc = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_subBeat};
    SLDataSink destination = {&out_loc, NULL};

    // create audio player
    const SLInterfaceID ids[] = {SL_IID_VOLUME};
    const SLboolean req[] = {SL_BOOLEAN_TRUE};
    result = (*engine_itf_subBeat)->CreateAudioPlayer(engine_itf_subBeat, &filePlayer_obj_subBeat_5, &audioSrc, &destination,
                                                      1, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*filePlayer_obj_subBeat_5)->Realize(filePlayer_obj_subBeat_5, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*filePlayer_obj_subBeat_5)->GetInterface(filePlayer_obj_subBeat_5, SL_IID_PLAY, &filePlayer_itf_subBeat_5);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    result = (*filePlayer_obj_subBeat_5)->GetInterface(filePlayer_obj_subBeat_5, SL_IID_VOLUME, &filePlayerVolume_subBeat_5);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    return JNI_TRUE;
}


// set the playing state for the asset audio player
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_setPlayStateSubBeat5(JNIEnv* env,
                                                                            jclass clazz, jboolean isPlaying)
{
    SLresult result;

    // make sure the asset audio player was created
    if (NULL != filePlayer_itf_subBeat_5) {

        // set the player's state
        result = (*filePlayer_itf_subBeat_5)->SetPlayState(filePlayer_itf_subBeat_5, isPlaying ?
                                                                                     SL_PLAYSTATE_PLAYING
                                                                                               : SL_PLAYSTATE_STOPPED);
        //assert(SL_RESULT_SUCCESS == result);
        (void) result;
    }
}


// ==========================================================================================
// SIXTH SET
// ==========================================================================================
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSubBeatAudioBuffer6(JNIEnv* env,
                                                                                 jclass clazz, jint sampleRate, jint bufSize)
{
    SLresult result;
    if (sampleRate >= 0 && bufSize >= 0 ) {
        bqPlayerSampleRate_subBeat = sampleRate * 1000;
        bqPlayerBufSize_subBeat = bufSize;
    }

    // configure audio source
    SLDataLocator_AndroidSimpleBufferQueue in_loc;
    in_loc.locatorType = SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE;
    in_loc.numBuffers = 1;
    SLDataFormat_PCM format_pcm = {SL_DATAFORMAT_PCM, 1, SL_SAMPLINGRATE_8,
                                   SL_PCMSAMPLEFORMAT_FIXED_16, SL_PCMSAMPLEFORMAT_FIXED_16,
                                   SL_SPEAKER_FRONT_CENTER, SL_BYTEORDER_LITTLEENDIAN};

    if(bqPlayerSampleRate_subBeat) {
        format_pcm.samplesPerSec = bqPlayerSampleRate_subBeat;       //sample rate in mili second
    }
    SLDataSource audioSrc = {&in_loc, &format_pcm};  // link audioSrc to this buffer (in_loc)

    // configure audio OUTPUT MIX -  The player will link to this destination
    SLDataLocator_OutputMix out_loc_SubBeat_6 = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_subBeat};  // { out_loc_SubBeat.locatorType, outputMix }
    SLDataSink destination = {&out_loc_SubBeat_6, NULL};

    // Add volume control
    const SLInterfaceID ids[] = {SL_IID_VOLUME, SL_IID_ANDROIDSIMPLEBUFFERQUEUE};
    const SLboolean req[] = {SL_BOOLEAN_TRUE, SL_BOOLEAN_TRUE};

    result = (*engine_itf_subBeat)->CreateAudioPlayer(engine_itf_subBeat, &buffer_obj_subBeat_6, &audioSrc, &destination,
                                                      bqPlayerSampleRate_subBeat? 2 : 3, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*buffer_obj_subBeat_6)->Realize(buffer_obj_subBeat_6, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*buffer_obj_subBeat_6)->GetInterface(buffer_obj_subBeat_6, SL_IID_PLAY, &buffer_itf_subBeat_6);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the volume interface
    result = (*buffer_obj_subBeat_6)->GetInterface(buffer_obj_subBeat_6, SL_IID_VOLUME, &filePlayerVolume_subBeat_6);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the buffer queue interface
    result = (*buffer_obj_subBeat_6)->GetInterface(buffer_obj_subBeat_6, SL_IID_BUFFERQUEUE,
                                                   &buf_q_subBeat_6);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;
}

// get asset (input wav file) for the audio player
jboolean Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSoundPlayerSubBeat6(JNIEnv* env, jclass clazz,
                                                                                     jobject assetManager, jstring filename)
{
    SLresult result;

    // convert Java string to UTF-8
    const char *utf8 = (*env)->GetStringUTFChars(env, filename, NULL);
    assert(NULL != utf8);

    // use asset manager to open asset by filename
    AAssetManager* mgr = AAssetManager_fromJava(env, assetManager);
    assert(NULL != mgr);
    AAsset* asset = AAssetManager_open(mgr, utf8, AASSET_MODE_UNKNOWN);

    // release the Java string and UTF-8
    (*env)->ReleaseStringUTFChars(env, filename, utf8);

    // the asset might not be found
    if (NULL == asset) {
        return JNI_FALSE;
    }

    // open asset as file descriptor
    off_t start, length;
    int fd = AAsset_openFileDescriptor(asset, &start, &length);
    assert(0 <= fd);
    AAsset_close(asset);

    // configure audio source
    SLDataLocator_AndroidFD loc_fd = {SL_DATALOCATOR_ANDROIDFD, fd, start, length};
    SLDataFormat_MIME format_mime = {SL_DATAFORMAT_MIME, NULL, SL_CONTAINERTYPE_UNSPECIFIED};
    SLDataSource audioSrc = {&loc_fd, &format_mime};

    // configure audio sink
    SLDataLocator_OutputMix out_loc = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_subBeat};
    SLDataSink destination = {&out_loc, NULL};

    // create audio player
    const SLInterfaceID ids[] = {SL_IID_VOLUME};
    const SLboolean req[] = {SL_BOOLEAN_TRUE};
    result = (*engine_itf_subBeat)->CreateAudioPlayer(engine_itf_subBeat, &filePlayer_obj_subBeat_6, &audioSrc, &destination,
                                                      1, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*filePlayer_obj_subBeat_6)->Realize(filePlayer_obj_subBeat_6, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*filePlayer_obj_subBeat_6)->GetInterface(filePlayer_obj_subBeat_6, SL_IID_PLAY, &filePlayer_itf_subBeat_6);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    result = (*filePlayer_obj_subBeat_6)->GetInterface(filePlayer_obj_subBeat_6, SL_IID_VOLUME, &filePlayerVolume_subBeat_6);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    return JNI_TRUE;
}


// set the playing state for the asset audio player
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_setPlayStateSubBeat6(JNIEnv* env,
                                                                            jclass clazz, jboolean isPlaying)
{
    SLresult result;

    // make sure the asset audio player was created
    if (NULL != filePlayer_itf_subBeat_6) {

        // set the player's state
        result = (*filePlayer_itf_subBeat_6)->SetPlayState(filePlayer_itf_subBeat_6, isPlaying ?
                                                                                     SL_PLAYSTATE_PLAYING
                                                                                               : SL_PLAYSTATE_STOPPED);
        //assert(SL_RESULT_SUCCESS == result);
        (void) result;
    }
}


// ==========================================================================================
// SEVENTH SET
// ==========================================================================================
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSubBeatAudioBuffer7(JNIEnv* env,
                                                                                 jclass clazz, jint sampleRate, jint bufSize)
{
    SLresult result;
    if (sampleRate >= 0 && bufSize >= 0 ) {
        bqPlayerSampleRate_subBeat = sampleRate * 1000;
        bqPlayerBufSize_subBeat = bufSize;
    }

    // configure audio source
    SLDataLocator_AndroidSimpleBufferQueue in_loc;
    in_loc.locatorType = SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE;
    in_loc.numBuffers = 1;
    SLDataFormat_PCM format_pcm = {SL_DATAFORMAT_PCM, 1, SL_SAMPLINGRATE_8,
                                   SL_PCMSAMPLEFORMAT_FIXED_16, SL_PCMSAMPLEFORMAT_FIXED_16,
                                   SL_SPEAKER_FRONT_CENTER, SL_BYTEORDER_LITTLEENDIAN};

    if(bqPlayerSampleRate_subBeat) {
        format_pcm.samplesPerSec = bqPlayerSampleRate_subBeat;       //sample rate in mili second
    }
    SLDataSource audioSrc = {&in_loc, &format_pcm};  // link audioSrc to this buffer (in_loc)

    // configure audio OUTPUT MIX -  The player will link to this destination
    SLDataLocator_OutputMix out_loc_SubBeat_7 = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_subBeat};  // { out_loc_SubBeat.locatorType, outputMix }
    SLDataSink destination = {&out_loc_SubBeat_7, NULL};

    // Add volume control
    const SLInterfaceID ids[] = {SL_IID_VOLUME, SL_IID_ANDROIDSIMPLEBUFFERQUEUE};
    const SLboolean req[] = {SL_BOOLEAN_TRUE, SL_BOOLEAN_TRUE};

    result = (*engine_itf_subBeat)->CreateAudioPlayer(engine_itf_subBeat, &buffer_obj_subBeat_7, &audioSrc, &destination,
                                                      bqPlayerSampleRate_subBeat? 2 : 3, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*buffer_obj_subBeat_7)->Realize(buffer_obj_subBeat_7, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*buffer_obj_subBeat_7)->GetInterface(buffer_obj_subBeat_7, SL_IID_PLAY, &buffer_itf_subBeat_7);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the volume interface
    result = (*buffer_obj_subBeat_7)->GetInterface(buffer_obj_subBeat_7, SL_IID_VOLUME, &filePlayerVolume_subBeat_7);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the buffer queue interface
    result = (*buffer_obj_subBeat_7)->GetInterface(buffer_obj_subBeat_7, SL_IID_BUFFERQUEUE,
                                                   &buf_q_subBeat_7);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;
}

// get asset (input wav file) for the audio player
jboolean Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSoundPlayerSubBeat7(JNIEnv* env, jclass clazz,
                                                                                     jobject assetManager, jstring filename)
{
    SLresult result;

    // convert Java string to UTF-8
    const char *utf8 = (*env)->GetStringUTFChars(env, filename, NULL);
    assert(NULL != utf8);

    // use asset manager to open asset by filename
    AAssetManager* mgr = AAssetManager_fromJava(env, assetManager);
    assert(NULL != mgr);
    AAsset* asset = AAssetManager_open(mgr, utf8, AASSET_MODE_UNKNOWN);

    // release the Java string and UTF-8
    (*env)->ReleaseStringUTFChars(env, filename, utf8);

    // the asset might not be found
    if (NULL == asset) {
        return JNI_FALSE;
    }

    // open asset as file descriptor
    off_t start, length;
    int fd = AAsset_openFileDescriptor(asset, &start, &length);
    assert(0 <= fd);
    AAsset_close(asset);

    // configure audio source
    SLDataLocator_AndroidFD loc_fd = {SL_DATALOCATOR_ANDROIDFD, fd, start, length};
    SLDataFormat_MIME format_mime = {SL_DATAFORMAT_MIME, NULL, SL_CONTAINERTYPE_UNSPECIFIED};
    SLDataSource audioSrc = {&loc_fd, &format_mime};

    // configure audio sink
    SLDataLocator_OutputMix out_loc = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_subBeat};
    SLDataSink destination = {&out_loc, NULL};

    // create audio player
    const SLInterfaceID ids[] = {SL_IID_VOLUME};
    const SLboolean req[] = {SL_BOOLEAN_TRUE};
    result = (*engine_itf_subBeat)->CreateAudioPlayer(engine_itf_subBeat, &filePlayer_obj_subBeat_7, &audioSrc, &destination,
                                                      1, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*filePlayer_obj_subBeat_7)->Realize(filePlayer_obj_subBeat_7, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*filePlayer_obj_subBeat_7)->GetInterface(filePlayer_obj_subBeat_7, SL_IID_PLAY, &filePlayer_itf_subBeat_7);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    result = (*filePlayer_obj_subBeat_7)->GetInterface(filePlayer_obj_subBeat_7, SL_IID_VOLUME, &filePlayerVolume_subBeat_7);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    return JNI_TRUE;
}


// set the playing state for the asset audio player
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_setPlayStateSubBeat7(JNIEnv* env,
                                                                            jclass clazz, jboolean isPlaying)
{
    SLresult result;

    // make sure the asset audio player was created
    if (NULL != filePlayer_itf_subBeat_7) {

        // set the player's state
        result = (*filePlayer_itf_subBeat_7)->SetPlayState(filePlayer_itf_subBeat_7, isPlaying ?
                                                                                     SL_PLAYSTATE_PLAYING
                                                                                               : SL_PLAYSTATE_STOPPED);
        //assert(SL_RESULT_SUCCESS == result);
        (void) result;
    }
}


// ==========================================================================================
// EIGHTH SET
// ==========================================================================================
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSubBeatAudioBuffer8(JNIEnv* env,
                                                                                 jclass clazz, jint sampleRate, jint bufSize)
{
    SLresult result;
    if (sampleRate >= 0 && bufSize >= 0 ) {
        bqPlayerSampleRate_subBeat = sampleRate * 1000;
        bqPlayerBufSize_subBeat = bufSize;
    }

    // configure audio source
    SLDataLocator_AndroidSimpleBufferQueue in_loc;
    in_loc.locatorType = SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE;
    in_loc.numBuffers = 1;
    SLDataFormat_PCM format_pcm = {SL_DATAFORMAT_PCM, 1, SL_SAMPLINGRATE_8,
                                   SL_PCMSAMPLEFORMAT_FIXED_16, SL_PCMSAMPLEFORMAT_FIXED_16,
                                   SL_SPEAKER_FRONT_CENTER, SL_BYTEORDER_LITTLEENDIAN};

    if(bqPlayerSampleRate_subBeat) {
        format_pcm.samplesPerSec = bqPlayerSampleRate_subBeat;       //sample rate in mili second
    }
    SLDataSource audioSrc = {&in_loc, &format_pcm};  // link audioSrc to this buffer (in_loc)

    // configure audio OUTPUT MIX -  The player will link to this destination
    SLDataLocator_OutputMix out_loc_SubBeat_8 = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_subBeat};  // { out_loc_SubBeat.locatorType, outputMix }
    SLDataSink destination = {&out_loc_SubBeat_8, NULL};

    // Add volume control
    const SLInterfaceID ids[] = {SL_IID_VOLUME, SL_IID_ANDROIDSIMPLEBUFFERQUEUE};
    const SLboolean req[] = {SL_BOOLEAN_TRUE, SL_BOOLEAN_TRUE};

    result = (*engine_itf_subBeat)->CreateAudioPlayer(engine_itf_subBeat, &buffer_obj_subBeat_8, &audioSrc, &destination,
                                                      bqPlayerSampleRate_subBeat? 2 : 3, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*buffer_obj_subBeat_8)->Realize(buffer_obj_subBeat_8, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*buffer_obj_subBeat_8)->GetInterface(buffer_obj_subBeat_8, SL_IID_PLAY, &buffer_itf_subBeat_8);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the volume interface
    result = (*buffer_obj_subBeat_8)->GetInterface(buffer_obj_subBeat_8, SL_IID_VOLUME, &filePlayerVolume_subBeat_8);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the buffer queue interface
    result = (*buffer_obj_subBeat_8)->GetInterface(buffer_obj_subBeat_8, SL_IID_BUFFERQUEUE,
                                                   &buf_q_subBeat_8);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;
}

// get asset (input wav file) for the audio player
jboolean Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSoundPlayerSubBeat8(JNIEnv* env, jclass clazz,
                                                                                     jobject assetManager, jstring filename)
{
    SLresult result;

    // convert Java string to UTF-8
    const char *utf8 = (*env)->GetStringUTFChars(env, filename, NULL);
    assert(NULL != utf8);

    // use asset manager to open asset by filename
    AAssetManager* mgr = AAssetManager_fromJava(env, assetManager);
    assert(NULL != mgr);
    AAsset* asset = AAssetManager_open(mgr, utf8, AASSET_MODE_UNKNOWN);

    // release the Java string and UTF-8
    (*env)->ReleaseStringUTFChars(env, filename, utf8);

    // the asset might not be found
    if (NULL == asset) {
        return JNI_FALSE;
    }

    // open asset as file descriptor
    off_t start, length;
    int fd = AAsset_openFileDescriptor(asset, &start, &length);
    assert(0 <= fd);
    AAsset_close(asset);

    // configure audio source
    SLDataLocator_AndroidFD loc_fd = {SL_DATALOCATOR_ANDROIDFD, fd, start, length};
    SLDataFormat_MIME format_mime = {SL_DATAFORMAT_MIME, NULL, SL_CONTAINERTYPE_UNSPECIFIED};
    SLDataSource audioSrc = {&loc_fd, &format_mime};

    // configure audio sink
    SLDataLocator_OutputMix out_loc = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_subBeat};
    SLDataSink destination = {&out_loc, NULL};

    // create audio player
    const SLInterfaceID ids[] = {SL_IID_VOLUME};
    const SLboolean req[] = {SL_BOOLEAN_TRUE};
    result = (*engine_itf_subBeat)->CreateAudioPlayer(engine_itf_subBeat, &filePlayer_obj_subBeat_8, &audioSrc, &destination,
                                                      1, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*filePlayer_obj_subBeat_8)->Realize(filePlayer_obj_subBeat_8, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*filePlayer_obj_subBeat_8)->GetInterface(filePlayer_obj_subBeat_8, SL_IID_PLAY, &filePlayer_itf_subBeat_8);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    result = (*filePlayer_obj_subBeat_8)->GetInterface(filePlayer_obj_subBeat_8, SL_IID_VOLUME, &filePlayerVolume_subBeat_8);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    return JNI_TRUE;
}


// set the playing state for the asset audio player
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_setPlayStateSubBeat8(JNIEnv* env,
                                                                            jclass clazz, jboolean isPlaying)
{
    SLresult result;

    // make sure the asset audio player was created
    if (NULL != filePlayer_itf_subBeat_8) {

        // set the player's state
        result = (*filePlayer_itf_subBeat_8)->SetPlayState(filePlayer_itf_subBeat_8, isPlaying ?
                                                                                     SL_PLAYSTATE_PLAYING
                                                                                               : SL_PLAYSTATE_STOPPED);
        //assert(SL_RESULT_SUCCESS == result);
        (void) result;
    }
}


// ==========================================================================================
// NINETH SET
// ==========================================================================================
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSubBeatAudioBuffer9(JNIEnv* env,
                                                                                 jclass clazz, jint sampleRate, jint bufSize)
{
    SLresult result;
    if (sampleRate >= 0 && bufSize >= 0 ) {
        bqPlayerSampleRate_subBeat = sampleRate * 1000;
        bqPlayerBufSize_subBeat = bufSize;
    }

    // configure audio source
    SLDataLocator_AndroidSimpleBufferQueue in_loc;
    in_loc.locatorType = SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE;
    in_loc.numBuffers = 1;
    SLDataFormat_PCM format_pcm = {SL_DATAFORMAT_PCM, 1, SL_SAMPLINGRATE_8,
                                   SL_PCMSAMPLEFORMAT_FIXED_16, SL_PCMSAMPLEFORMAT_FIXED_16,
                                   SL_SPEAKER_FRONT_CENTER, SL_BYTEORDER_LITTLEENDIAN};

    if(bqPlayerSampleRate_subBeat) {
        format_pcm.samplesPerSec = bqPlayerSampleRate_subBeat;       //sample rate in mili second
    }
    SLDataSource audioSrc = {&in_loc, &format_pcm};  // link audioSrc to this buffer (in_loc)

    // configure audio OUTPUT MIX -  The player will link to this destination
    SLDataLocator_OutputMix out_loc_SubBeat_9 = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_subBeat};  // { out_loc_SubBeat.locatorType, outputMix }
    SLDataSink destination = {&out_loc_SubBeat_9, NULL};

    // Add volume control
    const SLInterfaceID ids[] = {SL_IID_VOLUME, SL_IID_ANDROIDSIMPLEBUFFERQUEUE};
    const SLboolean req[] = {SL_BOOLEAN_TRUE, SL_BOOLEAN_TRUE};

    result = (*engine_itf_subBeat)->CreateAudioPlayer(engine_itf_subBeat, &buffer_obj_subBeat_9, &audioSrc, &destination,
                                                      bqPlayerSampleRate_subBeat? 2 : 3, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*buffer_obj_subBeat_9)->Realize(buffer_obj_subBeat_9, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*buffer_obj_subBeat_9)->GetInterface(buffer_obj_subBeat_9, SL_IID_PLAY, &buffer_itf_subBeat_9);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the volume interface
    result = (*buffer_obj_subBeat_9)->GetInterface(buffer_obj_subBeat_9, SL_IID_VOLUME, &filePlayerVolume_subBeat_9);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the buffer queue interface
    result = (*buffer_obj_subBeat_9)->GetInterface(buffer_obj_subBeat_9, SL_IID_BUFFERQUEUE,
                                                   &buf_q_subBeat_9);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;
}

// get asset (input wav file) for the audio player
jboolean Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSoundPlayerSubBeat9(JNIEnv* env, jclass clazz,
                                                                                     jobject assetManager, jstring filename)
{
    SLresult result;

    // convert Java string to UTF-8
    const char *utf8 = (*env)->GetStringUTFChars(env, filename, NULL);
    assert(NULL != utf8);

    // use asset manager to open asset by filename
    AAssetManager* mgr = AAssetManager_fromJava(env, assetManager);
    assert(NULL != mgr);
    AAsset* asset = AAssetManager_open(mgr, utf8, AASSET_MODE_UNKNOWN);

    // release the Java string and UTF-8
    (*env)->ReleaseStringUTFChars(env, filename, utf8);

    // the asset might not be found
    if (NULL == asset) {
        return JNI_FALSE;
    }

    // open asset as file descriptor
    off_t start, length;
    int fd = AAsset_openFileDescriptor(asset, &start, &length);
    assert(0 <= fd);
    AAsset_close(asset);

    // configure audio source
    SLDataLocator_AndroidFD loc_fd = {SL_DATALOCATOR_ANDROIDFD, fd, start, length};
    SLDataFormat_MIME format_mime = {SL_DATAFORMAT_MIME, NULL, SL_CONTAINERTYPE_UNSPECIFIED};
    SLDataSource audioSrc = {&loc_fd, &format_mime};

    // configure audio sink
    SLDataLocator_OutputMix out_loc = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_subBeat};
    SLDataSink destination = {&out_loc, NULL};

    // create audio player
    const SLInterfaceID ids[] = {SL_IID_VOLUME};
    const SLboolean req[] = {SL_BOOLEAN_TRUE};
    result = (*engine_itf_subBeat)->CreateAudioPlayer(engine_itf_subBeat, &filePlayer_obj_subBeat_9, &audioSrc, &destination,
                                                      1, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*filePlayer_obj_subBeat_9)->Realize(filePlayer_obj_subBeat_9, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*filePlayer_obj_subBeat_9)->GetInterface(filePlayer_obj_subBeat_9, SL_IID_PLAY, &filePlayer_itf_subBeat_9);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    result = (*filePlayer_obj_subBeat_9)->GetInterface(filePlayer_obj_subBeat_9, SL_IID_VOLUME, &filePlayerVolume_subBeat_9);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    return JNI_TRUE;
}


// set the playing state for the asset audio player
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_setPlayStateSubBeat9(JNIEnv* env,
                                                                            jclass clazz, jboolean isPlaying)
{
    SLresult result;

    // make sure the asset audio player was created
    if (NULL != filePlayer_itf_subBeat_9) {

        // set the player's state
        result = (*filePlayer_itf_subBeat_9)->SetPlayState(filePlayer_itf_subBeat_9, isPlaying ?
                                                                                     SL_PLAYSTATE_PLAYING
                                                                                               : SL_PLAYSTATE_STOPPED);
        //assert(SL_RESULT_SUCCESS == result);
        (void) result;
    }
}


// ==========================================================================================
// TENTH SET
// ==========================================================================================
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSubBeatAudioBuffer10(JNIEnv* env,
                                                                                 jclass clazz, jint sampleRate, jint bufSize)
{
    SLresult result;
    if (sampleRate >= 0 && bufSize >= 0 ) {
        bqPlayerSampleRate_subBeat = sampleRate * 1000;
        bqPlayerBufSize_subBeat = bufSize;
    }

    // configure audio source
    SLDataLocator_AndroidSimpleBufferQueue in_loc;
    in_loc.locatorType = SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE;
    in_loc.numBuffers = 1;
    SLDataFormat_PCM format_pcm = {SL_DATAFORMAT_PCM, 1, SL_SAMPLINGRATE_8,
                                   SL_PCMSAMPLEFORMAT_FIXED_16, SL_PCMSAMPLEFORMAT_FIXED_16,
                                   SL_SPEAKER_FRONT_CENTER, SL_BYTEORDER_LITTLEENDIAN};

    if(bqPlayerSampleRate_subBeat) {
        format_pcm.samplesPerSec = bqPlayerSampleRate_subBeat;       //sample rate in mili second
    }
    SLDataSource audioSrc = {&in_loc, &format_pcm};  // link audioSrc to this buffer (in_loc)

    // configure audio OUTPUT MIX -  The player will link to this destination
    SLDataLocator_OutputMix out_loc_SubBeat_10 = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_subBeat};  // { out_loc_SubBeat.locatorType, outputMix }
    SLDataSink destination = {&out_loc_SubBeat_10, NULL};

    // Add volume control
    const SLInterfaceID ids[] = {SL_IID_VOLUME, SL_IID_ANDROIDSIMPLEBUFFERQUEUE};
    const SLboolean req[] = {SL_BOOLEAN_TRUE, SL_BOOLEAN_TRUE};

    result = (*engine_itf_subBeat)->CreateAudioPlayer(engine_itf_subBeat, &buffer_obj_subBeat_10, &audioSrc, &destination,
                                                      bqPlayerSampleRate_subBeat? 2 : 3, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*buffer_obj_subBeat_10)->Realize(buffer_obj_subBeat_10, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*buffer_obj_subBeat_10)->GetInterface(buffer_obj_subBeat_10, SL_IID_PLAY, &buffer_itf_subBeat_10);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the volume interface
    result = (*buffer_obj_subBeat_10)->GetInterface(buffer_obj_subBeat_10, SL_IID_VOLUME, &filePlayerVolume_subBeat_10);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the buffer queue interface
    result = (*buffer_obj_subBeat_10)->GetInterface(buffer_obj_subBeat_10, SL_IID_BUFFERQUEUE,
                                                   &buf_q_subBeat_10);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;
}

// get asset (input wav file) for the audio player
jboolean Java_com_freeversion_davesapp_libertymetronome_MainActivity_createSoundPlayerSubBeat10(JNIEnv* env, jclass clazz,
                                                                                     jobject assetManager, jstring filename)
{
    SLresult result;

    // convert Java string to UTF-8
    const char *utf8 = (*env)->GetStringUTFChars(env, filename, NULL);
    assert(NULL != utf8);

    // use asset manager to open asset by filename
    AAssetManager* mgr = AAssetManager_fromJava(env, assetManager);
    assert(NULL != mgr);
    AAsset* asset = AAssetManager_open(mgr, utf8, AASSET_MODE_UNKNOWN);

    // release the Java string and UTF-8
    (*env)->ReleaseStringUTFChars(env, filename, utf8);

    // the asset might not be found
    if (NULL == asset) {
        return JNI_FALSE;
    }

    // open asset as file descriptor
    off_t start, length;
    int fd = AAsset_openFileDescriptor(asset, &start, &length);
    assert(0 <= fd);
    AAsset_close(asset);

    // configure audio source
    SLDataLocator_AndroidFD loc_fd = {SL_DATALOCATOR_ANDROIDFD, fd, start, length};
    SLDataFormat_MIME format_mime = {SL_DATAFORMAT_MIME, NULL, SL_CONTAINERTYPE_UNSPECIFIED};
    SLDataSource audioSrc = {&loc_fd, &format_mime};

    // configure audio sink
    SLDataLocator_OutputMix out_loc = {SL_DATALOCATOR_OUTPUTMIX, output_MixObject_subBeat};
    SLDataSink destination = {&out_loc, NULL};

    // create audio player
    const SLInterfaceID ids[] = {SL_IID_VOLUME};
    const SLboolean req[] = {SL_BOOLEAN_TRUE};
    result = (*engine_itf_subBeat)->CreateAudioPlayer(engine_itf_subBeat, &filePlayer_obj_subBeat_10, &audioSrc, &destination,
                                                      1, ids, req);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // realize the player
    result = (*filePlayer_obj_subBeat_10)->Realize(filePlayer_obj_subBeat_10, SL_BOOLEAN_FALSE);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    // get the play interface
    result = (*filePlayer_obj_subBeat_10)->GetInterface(filePlayer_obj_subBeat_10, SL_IID_PLAY, &filePlayer_itf_subBeat_10);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    result = (*filePlayer_obj_subBeat_10)->GetInterface(filePlayer_obj_subBeat_10, SL_IID_VOLUME, &filePlayerVolume_subBeat_10);
    //assert(SL_RESULT_SUCCESS == result);
    //(void)result;

    return JNI_TRUE;
}


// set the playing state for the asset audio player
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_setPlayStateSubBeat10(JNIEnv* env,
                                                                            jclass clazz, jboolean isPlaying)
{
    SLresult result;

    // make sure the asset audio player was created
    if (NULL != filePlayer_itf_subBeat_10) {

        // set the player's state
        result = (*filePlayer_itf_subBeat_10)->SetPlayState(filePlayer_itf_subBeat_10, isPlaying ?
                                                                                     SL_PLAYSTATE_PLAYING
                                                                                               : SL_PLAYSTATE_STOPPED);
        //assert(SL_RESULT_SUCCESS == result);
        (void) result;
    }
}




// ==============================================================================
// ==============================================================================
//  VOLUME CONTROLS
// ==============================================================================
// ==============================================================================
//  MainBeat Volume
// ==============================================================================

static SLVolumeItf getVolumeMainBeat(int i)
{
    //if (output_MixObject_vol_mainBeat != NULL)
    //    return output_MixObject_vol_mainBeat;
    switch (i) {
        case 1:
            if (filePlayerVolume_mainBeat_1 != NULL)
                return filePlayerVolume_mainBeat_1;
            break;
        case 2:
            if (filePlayerVolume_mainBeat_2 != NULL)
                return filePlayerVolume_mainBeat_2;
            break;
        case 3:
            if (filePlayerVolume_mainBeat_3 != NULL)
                return filePlayerVolume_mainBeat_3;
            break;
        case 4:
            if (filePlayerVolume_mainBeat_4 != NULL)
                return filePlayerVolume_mainBeat_4;
            break;
        case 5:
            if (filePlayerVolume_mainBeat_5 != NULL)
                return filePlayerVolume_mainBeat_5;
            break;
    }
}

void Java_com_freeversion_davesapp_libertymetronome_MainActivity_setVolumeMainBeat(JNIEnv* env, jclass clazz,
                                                                      jint millibel)
{
    SLresult result;
    SLVolumeItf volumeItf;

    volumeItf= getVolumeMainBeat(1);
    if (NULL != filePlayerVolume_mainBeat_1) {
        result = (*volumeItf)->SetVolumeLevel(volumeItf, millibel);
        //assert(SL_RESULT_SUCCESS == result);
        //(void)result;
    }
    volumeItf = getVolumeMainBeat(2);
    if (NULL != filePlayerVolume_mainBeat_2) {
        result = (*volumeItf)->SetVolumeLevel(volumeItf, millibel);
        //assert(SL_RESULT_SUCCESS == result);
        //(void)result;
    }
    volumeItf = getVolumeMainBeat(3);
    if (NULL != filePlayerVolume_mainBeat_3) {
        result = (*volumeItf)->SetVolumeLevel(volumeItf, millibel);
        //assert(SL_RESULT_SUCCESS == result);
        //(void)result;
    }
    volumeItf = getVolumeMainBeat(4);
    if (NULL != filePlayerVolume_mainBeat_4) {
        result = (*volumeItf)->SetVolumeLevel(volumeItf, millibel);
        //assert(SL_RESULT_SUCCESS == result);
        //(void)result;
    }
    volumeItf = getVolumeMainBeat(5);
    if (NULL != filePlayerVolume_mainBeat_5) {
        result = (*volumeItf)->SetVolumeLevel(volumeItf, millibel);
        //assert(SL_RESULT_SUCCESS == result);
        //(void)result;
    }
}



// ==============================================================================
//  SubBeat Volume
// ==============================================================================

static SLVolumeItf getVolumeSubBeat(int i)
{
    //if (output_MixObject_vol_subBeat != NULL)
    //    return output_MixObject_vol_subBeat;
    switch (i) {
        case 1:
            if (filePlayerVolume_subBeat_1 != NULL)
                return filePlayerVolume_subBeat_1;
            break;
        case 2:
            if (filePlayerVolume_subBeat_2 != NULL)
                return filePlayerVolume_subBeat_2;
            break;
        case 3:
            if (filePlayerVolume_subBeat_3 != NULL)
                return filePlayerVolume_subBeat_3;
            break;
        case 4:
            if (filePlayerVolume_subBeat_4 != NULL)
                return filePlayerVolume_subBeat_4;
            break;
        case 5:
            if (filePlayerVolume_subBeat_5 != NULL)
                return filePlayerVolume_subBeat_5;
            break;
        case 6:
            if (filePlayerVolume_subBeat_6 != NULL)
                return filePlayerVolume_subBeat_6;
            break;
        case 7:
            if (filePlayerVolume_subBeat_7 != NULL)
                return filePlayerVolume_subBeat_7;
            break;
        case 8:
            if (filePlayerVolume_subBeat_8 != NULL)
                return filePlayerVolume_subBeat_8;
            break;
        case 9:
            if (filePlayerVolume_subBeat_9 != NULL)
                return filePlayerVolume_subBeat_9;
            break;
        case 10:
            if (filePlayerVolume_subBeat_10 != NULL)
                return filePlayerVolume_subBeat_10;
            break;
    }
}

void Java_com_freeversion_davesapp_libertymetronome_MainActivity_setVolumeSubBeat(JNIEnv* env, jclass clazz,
                                                                         jint millibel)
{
    SLresult result;
    SLVolumeItf volumeItf;

    volumeItf= getVolumeSubBeat(1);
    if (NULL != filePlayerVolume_subBeat_1) {
        result = (*volumeItf)->SetVolumeLevel(volumeItf, millibel);
        //assert(SL_RESULT_SUCCESS == result);
        //(void)result;
    }
    volumeItf = getVolumeSubBeat(2);
    if (NULL != filePlayerVolume_subBeat_2) {
        result = (*volumeItf)->SetVolumeLevel(volumeItf, millibel);
        //assert(SL_RESULT_SUCCESS == result);
        //(void)result;
    }
    volumeItf = getVolumeSubBeat(3);
    if (NULL != filePlayerVolume_subBeat_3) {
        result = (*volumeItf)->SetVolumeLevel(volumeItf, millibel);
        //assert(SL_RESULT_SUCCESS == result);
        //(void)result;
    }
    volumeItf = getVolumeSubBeat(4);
    if (NULL != filePlayerVolume_subBeat_4) {
        result = (*volumeItf)->SetVolumeLevel(volumeItf, millibel);
        //assert(SL_RESULT_SUCCESS == result);
        //(void)result;
    }
    volumeItf = getVolumeSubBeat(5);
    if (NULL != filePlayerVolume_subBeat_5) {
        result = (*volumeItf)->SetVolumeLevel(volumeItf, millibel);
        //assert(SL_RESULT_SUCCESS == result);
        //(void)result;
    }
    volumeItf = getVolumeSubBeat(6);
    if (NULL != filePlayerVolume_subBeat_6) {
        result = (*volumeItf)->SetVolumeLevel(volumeItf, millibel);
        //assert(SL_RESULT_SUCCESS == result);
        //(void)result;
    }
    volumeItf = getVolumeSubBeat(7);
    if (NULL != filePlayerVolume_subBeat_7) {
        result = (*volumeItf)->SetVolumeLevel(volumeItf, millibel);
        //assert(SL_RESULT_SUCCESS == result);
        //(void)result;
    }
    volumeItf = getVolumeSubBeat(8);
    if (NULL != filePlayerVolume_subBeat_8) {
        result = (*volumeItf)->SetVolumeLevel(volumeItf, millibel);
        //assert(SL_RESULT_SUCCESS == result);
        //(void)result;
    }
    volumeItf = getVolumeSubBeat(9);
    if (NULL != filePlayerVolume_subBeat_9) {
        result = (*volumeItf)->SetVolumeLevel(volumeItf, millibel);
        //assert(SL_RESULT_SUCCESS == result);
        //(void)result;
    }
    volumeItf = getVolumeSubBeat(10);
    if (NULL != filePlayerVolume_subBeat_10) {
        result = (*volumeItf)->SetVolumeLevel(volumeItf, millibel);
        //assert(SL_RESULT_SUCCESS == result);
        //(void)result;
    }
}




//===============================================================================
//===============================================================================
//===============================================================================
//
//   SHUT DOWN SECTION
//
//===============================================================================
//===============================================================================
//===============================================================================

// shut down the native audio system

//===============================================================================
// MAIN BEAT ENGINE
//===============================================================================
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_shutdownMainBeat(JNIEnv* env, jclass clazz)
{
    // destroy buffer queue audio player object, and invalidate all associated interfaces
    if (buffer_obj_mainBeat_1 != NULL) {
        (*buffer_obj_mainBeat_1)->Destroy(buffer_obj_mainBeat_1);
        buffer_obj_mainBeat_1 = NULL;
        buffer_itf_mainBeat_1 = NULL;
        buf_q_mainBeat_1 = NULL;
        //bqPlayerEffectSend = NULL;
        //bqPlayerMuteSolo = NULL;
        player_vol_mainBeat = NULL;
    }
    if (buffer_obj_mainBeat_2 != NULL) {
        (*buffer_obj_mainBeat_2)->Destroy(buffer_obj_mainBeat_2);
        buffer_obj_mainBeat_2 = NULL;
        buffer_itf_mainBeat_2 = NULL;
        buf_q_mainBeat_2 = NULL;
        //bqPlayerEffectSend = NULL;
        //bqPlayerMuteSolo = NULL;
        //player_vol_mainBeat = NULL;
    }if (buffer_obj_mainBeat_3 != NULL) {
        (*buffer_obj_mainBeat_3)->Destroy(buffer_obj_mainBeat_3);
        buffer_obj_mainBeat_3 = NULL;
        buffer_itf_mainBeat_3 = NULL;
        buf_q_mainBeat_3 = NULL;
        //bqPlayerEffectSend = NULL;
        //bqPlayerMuteSolo = NULL;
        //player_vol_mainBeat = NULL;
    }if (buffer_obj_mainBeat_4 != NULL) {
        (*buffer_obj_mainBeat_4)->Destroy(buffer_obj_mainBeat_4);
        buffer_obj_mainBeat_4 = NULL;
        buffer_itf_mainBeat_4 = NULL;
        buf_q_mainBeat_4 = NULL;
        //bqPlayerEffectSend = NULL;
        //bqPlayerMuteSolo = NULL;
        //player_vol_mainBeat = NULL;
    }if (buffer_obj_mainBeat_5 != NULL) {
        (*buffer_obj_mainBeat_5)->Destroy(buffer_obj_mainBeat_5);
        buffer_obj_mainBeat_5 = NULL;
        buffer_itf_mainBeat_5 = NULL;
        buf_q_mainBeat_5 = NULL;
        //bqPlayerEffectSend = NULL;
        //bqPlayerMuteSolo = NULL;
        //player_vol_mainBeat = NULL;
    }


    // destroy file descriptor audio player object, and invalidate all associated interfaces
    if (filePlayer_obj_mainBeat_1 != NULL) {
        (*filePlayer_obj_mainBeat_1)->Destroy(filePlayer_obj_mainBeat_1);
        filePlayer_obj_mainBeat_1 = NULL;
        filePlayer_itf_mainBeat_1 = NULL;
        //filePlayerMuteSolo_mainBeat_2 = NULL;
        filePlayerVolume_mainBeat_1 = NULL;
    }
    if (filePlayer_obj_mainBeat_2 != NULL) {
        (*filePlayer_obj_mainBeat_2)->Destroy(filePlayer_obj_mainBeat_2);
        filePlayer_obj_mainBeat_2 = NULL;
        filePlayer_itf_mainBeat_2 = NULL;
        //filePlayerMuteSolo_mainBeat_2 = NULL;
        filePlayerVolume_mainBeat_2 = NULL;
    }
    // destroy file descriptor audio player object, and invalidate all associated interfaces
    if (filePlayer_obj_mainBeat_3 != NULL) {
        (*filePlayer_obj_mainBeat_3)->Destroy(filePlayer_obj_mainBeat_3);
        filePlayer_obj_mainBeat_3 = NULL;
        filePlayer_itf_mainBeat_3 = NULL;
        //filePlayerMuteSolo_mainBeat_3 = NULL;
        filePlayerVolume_mainBeat_3 = NULL;
    }
    // destroy file descriptor audio player object, and invalidate all associated interfaces
    if (filePlayer_obj_mainBeat_4 != NULL) {
        (*filePlayer_obj_mainBeat_4)->Destroy(filePlayer_obj_mainBeat_4);
        filePlayer_obj_mainBeat_4 = NULL;
        filePlayer_itf_mainBeat_4 = NULL;
        //filePlayerMuteSolo_mainBeat_4 = NULL;
        filePlayerVolume_mainBeat_4 = NULL;
    }// destroy file descriptor audio player object, and invalidate all associated interfaces
    if (filePlayer_obj_mainBeat_5 != NULL) {
        (*filePlayer_obj_mainBeat_5)->Destroy(filePlayer_obj_mainBeat_5);
        filePlayer_obj_mainBeat_5 = NULL;
        filePlayer_itf_mainBeat_5 = NULL;
        //filePlayerMuteSolo_mainBeat_5 = NULL;
        filePlayerVolume_mainBeat_5 = NULL;
    }



    // destroy output mix object, and invalidate all associated interfaces
    if (output_MixObject_mainBeat != NULL) {
        (*output_MixObject_mainBeat)->Destroy(output_MixObject_mainBeat);
        output_MixObject_mainBeat = NULL;
        //outputMixEnvironmentalReverb = NULL;
    }

    // destroy engine object, and invalidate all associated interfaces
    if (engine_object_mainBeat != NULL) {
        (*engine_object_mainBeat)->Destroy(engine_object_mainBeat);
        engine_object_mainBeat = NULL;
        engine_itf_mainBeat = NULL;
    }

    pthread_mutex_destroy(&audioEngineLock_mainBeat);
}


//===============================================================================
// SUB BEAT ENGINE
//===============================================================================
void Java_com_freeversion_davesapp_libertymetronome_MainActivity_shutdownSubBeat(JNIEnv* env, jclass clazz)
{
    // destroy buffer queue audio player object, and invalidate all associated interfaces
    if (buffer_obj_subBeat_1 != NULL) {
        (*buffer_obj_subBeat_1)->Destroy(buffer_obj_subBeat_1);
        buffer_obj_subBeat_1 = NULL;
        buffer_itf_subBeat_1 = NULL;
        buf_q_subBeat_1 = NULL;
        //bqPlayerEffectSend = NULL;
        //bqPlayerMuteSolo = NULL;
        player_vol_subBeat = NULL;
    }
    if (buffer_obj_subBeat_2 != NULL) {
        (*buffer_obj_subBeat_2)->Destroy(buffer_obj_subBeat_2);
        buffer_obj_subBeat_2 = NULL;
        buffer_itf_subBeat_2 = NULL;
        buf_q_subBeat_2 = NULL;
        //bqPlayerEffectSend = NULL;
        //bqPlayerMuteSolo = NULL;
        //player_vol_subBeat = NULL;
    }if (buffer_obj_subBeat_3 != NULL) {
        (*buffer_obj_subBeat_3)->Destroy(buffer_obj_subBeat_3);
        buffer_obj_subBeat_3 = NULL;
        buffer_itf_subBeat_3 = NULL;
        buf_q_subBeat_3 = NULL;
        //bqPlayerEffectSend = NULL;
        //bqPlayerMuteSolo = NULL;
        //player_vol_subBeat = NULL;
    }if (buffer_obj_subBeat_4 != NULL) {
        (*buffer_obj_subBeat_4)->Destroy(buffer_obj_subBeat_4);
        buffer_obj_subBeat_4 = NULL;
        buffer_itf_subBeat_4 = NULL;
        buf_q_subBeat_4 = NULL;
        //bqPlayerEffectSend = NULL;
        //bqPlayerMuteSolo = NULL;
        //player_vol_subBeat = NULL;
    }if (buffer_obj_subBeat_5 != NULL) {
        (*buffer_obj_subBeat_5)->Destroy(buffer_obj_subBeat_5);
        buffer_obj_subBeat_5 = NULL;
        buffer_itf_subBeat_5 = NULL;
        buf_q_subBeat_5 = NULL;
        //bqPlayerEffectSend = NULL;
        //bqPlayerMuteSolo = NULL;
        //player_vol_subBeat = NULL;
    }if (buffer_obj_subBeat_6 != NULL) {
        (*buffer_obj_subBeat_6)->Destroy(buffer_obj_subBeat_6);
        buffer_obj_subBeat_6 = NULL;
        buffer_itf_subBeat_6 = NULL;
        buf_q_subBeat_6 = NULL;
        //bqPlayerEffectSend = NULL;
        //bqPlayerMuteSolo = NULL;
        //player_vol_subBeat = NULL;
    }if (buffer_obj_subBeat_7 != NULL) {
        (*buffer_obj_subBeat_7)->Destroy(buffer_obj_subBeat_7);
        buffer_obj_subBeat_7 = NULL;
        buffer_itf_subBeat_7 = NULL;
        buf_q_subBeat_7 = NULL;
        //bqPlayerEffectSend = NULL;
        //bqPlayerMuteSolo = NULL;
        //player_vol_subBeat = NULL;
    }if (buffer_obj_subBeat_8 != NULL) {
        (*buffer_obj_subBeat_8)->Destroy(buffer_obj_subBeat_8);
        buffer_obj_subBeat_8 = NULL;
        buffer_itf_subBeat_8 = NULL;
        buf_q_subBeat_8 = NULL;
        //bqPlayerEffectSend = NULL;
        //bqPlayerMuteSolo = NULL;
        //player_vol_subBeat = NULL;
    }if (buffer_obj_subBeat_9 != NULL) {
        (*buffer_obj_subBeat_9)->Destroy(buffer_obj_subBeat_9);
        buffer_obj_subBeat_9 = NULL;
        buffer_itf_subBeat_9 = NULL;
        buf_q_subBeat_9 = NULL;
        //bqPlayerEffectSend = NULL;
        //bqPlayerMuteSolo = NULL;
        //player_vol_subBeat = NULL;
    }if (buffer_obj_subBeat_10 != NULL) {
        (*buffer_obj_subBeat_10)->Destroy(buffer_obj_subBeat_10);
        buffer_obj_subBeat_10 = NULL;
        buffer_itf_subBeat_10 = NULL;
        buf_q_subBeat_10 = NULL;
        //bqPlayerEffectSend = NULL;
        //bqPlayerMuteSolo = NULL;
        //player_vol_subBeat = NULL;
    }




    // destroy file descriptor audio player object, and invalidate all associated interfaces
    if (filePlayer_obj_subBeat_1 != NULL) {
        (*filePlayer_obj_subBeat_1)->Destroy(filePlayer_obj_subBeat_1);
        filePlayer_obj_subBeat_1 = NULL;
        filePlayer_itf_subBeat_1 = NULL;
        //filePlayerMuteSolo_subBeat_2 = NULL;
        filePlayerVolume_subBeat_1 = NULL;
    }
    if (filePlayer_obj_subBeat_2 != NULL) {
        (*filePlayer_obj_subBeat_2)->Destroy(filePlayer_obj_subBeat_2);
        filePlayer_obj_subBeat_2 = NULL;
        filePlayer_itf_subBeat_2 = NULL;
        //filePlayerMuteSolo_subBeat_2 = NULL;
        filePlayerVolume_subBeat_2 = NULL;
    }
    // destroy file descriptor audio player object, and invalidate all associated interfaces
    if (filePlayer_obj_subBeat_3 != NULL) {
        (*filePlayer_obj_subBeat_3)->Destroy(filePlayer_obj_subBeat_3);
        filePlayer_obj_subBeat_3 = NULL;
        filePlayer_itf_subBeat_3 = NULL;
        //filePlayerMuteSolo_subBeat_3 = NULL;
        filePlayerVolume_subBeat_3 = NULL;
    }
    // destroy file descriptor audio player object, and invalidate all associated interfaces
    if (filePlayer_obj_subBeat_4 != NULL) {
        (*filePlayer_obj_subBeat_4)->Destroy(filePlayer_obj_subBeat_4);
        filePlayer_obj_subBeat_4 = NULL;
        filePlayer_itf_subBeat_4 = NULL;
        //filePlayerMuteSolo_subBeat_4 = NULL;
        filePlayerVolume_subBeat_4 = NULL;
    }// destroy file descriptor audio player object, and invalidate all associated interfaces
    if (filePlayer_obj_subBeat_5 != NULL) {
        (*filePlayer_obj_subBeat_5)->Destroy(filePlayer_obj_subBeat_5);
        filePlayer_obj_subBeat_5 = NULL;
        filePlayer_itf_subBeat_5 = NULL;
        //filePlayerMuteSolo_subBeat_5 = NULL;
        filePlayerVolume_subBeat_5 = NULL;
    }
    if (filePlayer_obj_subBeat_6 != NULL) {
        (*filePlayer_obj_subBeat_6)->Destroy(filePlayer_obj_subBeat_6);
        filePlayer_obj_subBeat_6 = NULL;
        filePlayer_itf_subBeat_6 = NULL;
        //filePlayerMuteSolo_subBeat_6 = NULL;
        filePlayerVolume_subBeat_6 = NULL;
    }
    if (filePlayer_obj_subBeat_7 != NULL) {
        (*filePlayer_obj_subBeat_7)->Destroy(filePlayer_obj_subBeat_7);
        filePlayer_obj_subBeat_7 = NULL;
        filePlayer_itf_subBeat_7 = NULL;
        //filePlayerMuteSolo_subBeat_7 = NULL;
        filePlayerVolume_subBeat_7 = NULL;
    }
    if (filePlayer_obj_subBeat_8 != NULL) {
        (*filePlayer_obj_subBeat_8)->Destroy(filePlayer_obj_subBeat_8);
        filePlayer_obj_subBeat_8 = NULL;
        filePlayer_itf_subBeat_8 = NULL;
        //filePlayerMuteSolo_subBeat_5 = NULL;
        filePlayerVolume_subBeat_8 = NULL;
    }
    if (filePlayer_obj_subBeat_9 != NULL) {
        (*filePlayer_obj_subBeat_9)->Destroy(filePlayer_obj_subBeat_9);
        filePlayer_obj_subBeat_9 = NULL;
        filePlayer_itf_subBeat_9 = NULL;
        //filePlayerMuteSolo_subBeat_5 = NULL;
        filePlayerVolume_subBeat_9 = NULL;
    }
    if (filePlayer_obj_subBeat_10 != NULL) {
        (*filePlayer_obj_subBeat_10)->Destroy(filePlayer_obj_subBeat_10);
        filePlayer_obj_subBeat_10 = NULL;
        filePlayer_itf_subBeat_10 = NULL;
        //filePlayerMuteSolo_subBeat_5 = NULL;
        filePlayerVolume_subBeat_10 = NULL;
    }



    // destroy output mix object, and invalidate all associated interfaces
    if (output_MixObject_subBeat != NULL) {
        (*output_MixObject_subBeat)->Destroy(output_MixObject_subBeat);
        output_MixObject_subBeat = NULL;
        //outputMixEnvironmentalReverb = NULL;
    }

    // destroy engine object, and invalidate all associated interfaces
    if (engine_object_subBeat != NULL) {
        (*engine_object_subBeat)->Destroy(engine_object_subBeat);
        engine_object_subBeat = NULL;
        engine_itf_subBeat = NULL;
    }

    pthread_mutex_destroy(&audioEngineLock_subBeat);
}